# MyApp (Örnek Android Projesi)

Bu, GitHub Actions ile otomatik APK üretimini göstermek için hazırlanmış minimal bir Android projesidir.

## Önemli Not: gradle-wrapper.jar

`gradle/wrapper/gradle-wrapper.jar` dosyası ikili (binary) bir dosyadır ve internet
erişimi olmayan bir ortamda üretilemez. Bu paket içinde bu jar dosyası YOKTUR.

Ekteki `build-apk.yml` workflow dosyası bunu otomatik olarak çözer: CI adımlarından
biri `gradle wrapper` komutunu çalıştırarak bu jar dosyasını her build öncesinde
kendisi üretir. Böylece siz hiçbir şey yapmadan `./gradlew assembleRelease` komutu
sorunsuz çalışır.

Eğer isterseniz, kendi bilgisayarınızda (Android Studio kurulu, internet bağlantısı olan)
projeyi bir kez açıp `gradle wrapper` çalıştırarak veya Android Studio'nun kendisiyle
projeyi senkronize ederek gerçek `gradle-wrapper.jar` dosyasını da projeye
kalıcı olarak ekleyebilirsiniz. Bu durumda CI workflow'undaki wrapper üretme adımı
sorunsuz bir şekilde atlanır (adım zaten var olan jar'ı fark eder ve hata vermez).

## Yapı

- `app/` — Uygulama modülü (Kotlin, minSdk 21, targetSdk/compileSdk 34)
- `settings.gradle`, `build.gradle` — Proje seviyesi Gradle yapılandırması
- `.github/workflows/build-apk.yml` — CI/CD pipeline (ayrı olarak paylaşıldı)
