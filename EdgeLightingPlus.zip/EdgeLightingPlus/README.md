# Edge Lighting+

Android bildirim geldiğinde ekran kenarlarında parlayan ışık (edge lighting)
efekti gösteren uygulama.

## "İkinci bildirim tetiklenmiyor" sorununun gerçek sebebi

Bu, tek başına bir kuyruk hatası değil — piyasadaki benzer uygulamaların en
sık karşılaştığı, dokümante edilmiş bir Android davranışı: **telefon
üreticisi (Samsung/Xiaomi/Huawei vb.) pil optimizasyonu, kullanılmayan
bildirim dinleyici servisini arka planda koparıyor.** İlk bildirim (servis
daha yeni bağlanmışken) çalışıyor, sonra sistem servisi öldürüyor ve
sonrakiler hiç ulaşmıyor. Bu sürümde buna karşı iki önlem var:

1. `EdgeLightingService.onListenerDisconnected()` içinde `requestRebind()`
   çağrılıyor — sistem servisi koparırsa otomatik yeniden bağlanmayı dener.
2. Uygulama içine **"Pil Optimizasyonunu Kapat"** butonu eklendi.
   Xiaomi/Huawei gibi cihazlarda ayrıca "Otomatik başlatma" (autostart)
   iznini açıp uygulamayı son uygulamalar ekranında kilitli tutmanız
   gerekir — bu, işletim sistemi seviyesinde bir kısıtlama olduğu için
   koddan tamamen çözülemez.

Ayrıca, art arda gelen bildirimlerin animasyonlarının üst üste binmeden
sırayla oynatılması için `EdgeOverlayManager` içinde FIFO kuyruk kullanılır.

## Yeni: Kural Motoru + Çoklu Animasyon

- **Kurallar:** Başlıkta veya açıklamada geçen bir kelimeye göre özel
  renk/animasyon tanımlayabilirsiniz (örn. başlık "selam" *içeriyorsa* —
  "selam canım" da eşleşir — kalp animasyonu tetiklenir). Birden fazla
  kural ekleyebilirsiniz; bir bildirim birden fazla kurala uyuyorsa hepsi
  sırayla (kuyrukta) oynatılır.
- **Animasyonlar:** Parlama (klasik glow), Kalpler (alttan yükselen),
  Kayma (kenar boyunca akan ışık / "geliş" efekti).

## Kurulum (yerelde derleme)

1. Android Studio ile bu klasörü açın (File > Open).
2. Gradle sync bitince Run tuşuna basın, veya:
   ```
   ./gradlew assembleDebug
   ```
3. APK: `app/build/outputs/apk/debug/app-debug.apk`

## GitHub üzerinden otomatik APK + Release

Bu depoya `.github/workflows/build-apk.yml` eklidir.

1. Bu klasörün tüm içeriğini bir GitHub reposuna push'layın.
2. Bir sürüm etiketi (tag) push edin:
   ```
   git tag v1.0.0
   git push origin v1.0.0
   ```
3. Actions sekmesinde iş otomatik başlar, APK'yı derler ve
   **Releases** kısmına `EdgeLightingPlus.apk` olarak ekler.
4. Sadece test etmek isterseniz Actions sekmesinden
   "Run workflow" (workflow_dispatch) ile de tetikleyip
   Artifacts kısmından indirebilirsiniz (tag atmadan release oluşmaz,
   sadece artifact yüklenir).

## Uygulamada gerekli izinler

- **Bildirim Erişimi** (Notification Access) — bildirimleri dinlemek için.
- **Ekranın üstünde gösterme** (Draw over other apps) — parlama efektini
  overlay olarak çizmek için.

Uygulama açılışında bu izinlerin durumunu gösterir ve izin verme
ekranlarına yönlendirir. "2 Bildirim Gibi Test Et" butonu, art arda iki
efekti tetikleyerek kuyruk düzeltmesini test etmenizi sağlar.
