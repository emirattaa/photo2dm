# Edge Lighting+

Android bildirim geldiğinde ekran kenarlarında parlayan ışık (edge lighting)
efekti gösteren uygulama. Art arda gelen bildirimlerin sırayla oynatılması
için `EdgeOverlayManager` içinde FIFO kuyruk kullanılır — bu, "ikinci
bildirim gelmiyor / görünmüyor" sorununu çözer.

## Kurulum (yerelde derleme)

1. Android Studio ile bu klasörü açın (File > Open).
2. Gradle sync bitince Run tuşuna basın, veya:
   ```
   ./gradlew assembleDebug
   ```
3. APK: `app/build/outputs/apk/debug/app-debug.apk`

## GitHub üzerinden otomatik APK + Release

Bu depoya `.github/workflows/build-apk.yml` eklidir.

1. Bu klasörün tüm içeriğini bir GitHub reposuna push'layın.
2. Bir sürüm etiketi (tag) push edin:
   ```
   git tag v1.0.0
   git push origin v1.0.0
   ```
3. Actions sekmesinde iş otomatik başlar, APK'yı derler ve
   **Releases** kısmına `EdgeLightingPlus.apk` olarak ekler.
4. Sadece test etmek isterseniz Actions sekmesinden
   "Run workflow" (workflow_dispatch) ile de tetikleyip
   Artifacts kısmından indirebilirsiniz (tag atmadan release oluşmaz,
   sadece artifact yüklenir).

## Uygulamada gerekli izinler

- **Bildirim Erişimi** (Notification Access) — bildirimleri dinlemek için.
- **Ekranın üstünde gösterme** (Draw over other apps) — parlama efektini
  overlay olarak çizmek için.

Uygulama açılışında bu izinlerin durumunu gösterir ve izin verme
ekranlarına yönlendirir. "2 Bildirim Gibi Test Et" butonu, art arda iki
efekti tetikleyerek kuyruk düzeltmesini test etmenizi sağlar.
