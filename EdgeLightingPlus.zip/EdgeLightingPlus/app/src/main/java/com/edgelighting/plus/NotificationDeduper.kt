package com.edgelighting.plus

/**
 * Aynı bildirim (aynı paket+id+tag) kısa süre içinde, içeriği değişmeden
 * tekrar "postlanırsa" (indirme ilerlemesi, medya oynatıcı güncellemesi,
 * mesajlaşma uygulamalarının arka planda sık sık güncellemesi gibi) bunu
 * gerçek/yeni bir bildirim gibi tekrar tetiklemeyi engeller. Bu, piyasadaki
 * benzer uygulamalarda en sık şikayet edilen "saçma yerlerde tetikleniyor"
 * sorununun ana kaynağıdır: onNotificationPosted her güncellemede tekrar
 * çağrılır, tek başına "yeni bildirim" anlamına gelmez.
 */
object NotificationDeduper {
    private const val DEDUPE_WINDOW_MS = 2500L
    private const val MAX_TRACKED = 200

    private val lastSeen = mutableMapOf<String, Pair<Int, Long>>()

    @Synchronized
    fun isDuplicate(key: String, contentHash: Int): Boolean {
        val now = System.currentTimeMillis()
        val previous = lastSeen[key]
        lastSeen[key] = contentHash to now

        if (lastSeen.size > MAX_TRACKED) {
            val cutoff = now - 60_000L
            lastSeen.entries.removeAll { it.value.second < cutoff }
        }

        return previous != null && previous.first == contentHash && (now - previous.second) < DEDUPE_WINDOW_MS
    }
}
