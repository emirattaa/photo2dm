package com.edgelighting.plus

/** Ortak arayüz: her animasyon tarzı (pulse/hearts/slide) bunu uygular. */
interface EdgeEffect {
    fun start(durationMs: Long, onFinished: () -> Unit)
}
