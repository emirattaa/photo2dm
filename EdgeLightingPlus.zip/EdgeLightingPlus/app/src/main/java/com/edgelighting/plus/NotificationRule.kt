package com.edgelighting.plus

import org.json.JSONArray
import org.json.JSONObject

/** Bir kuralın hangi alana bakacağını belirler. */
enum class RuleField { TITLE, TEXT }

/** Kenar aydınlatma animasyon tarzı. */
enum class AnimationStyle {
    PULSE,  // Kenarlar boyunca parlayıp sönme
    HEARTS, // Alttan yükselen kalpler
    SLIDE   // Kenar boyunca kayan ışık şeriti (geliş animasyonu)
}

/**
 * Kullanıcının tanımladığı tetikleme kuralı.
 * Örn: field=TITLE, keyword="selam" -> başlığında "selam" GEÇEN
 * (örn. "selam canım") her bildirimde tetiklenir (tam eşleşme değil, içerir).
 */
data class NotificationRule(
    val id: String,
    val field: RuleField,
    val keyword: String,
    val color: Int,
    val animationStyle: AnimationStyle
) {
    fun matches(title: String, text: String): Boolean {
        if (keyword.isBlank()) return false
        val haystack = if (field == RuleField.TITLE) title else text
        return haystack.contains(keyword, ignoreCase = true)
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("field", field.name)
        put("keyword", keyword)
        put("color", color)
        put("animationStyle", animationStyle.name)
    }

    companion object {
        fun fromJson(json: JSONObject): NotificationRule = NotificationRule(
            id = json.getString("id"),
            field = RuleField.valueOf(json.getString("field")),
            keyword = json.getString("keyword"),
            color = json.getInt("color"),
            animationStyle = AnimationStyle.valueOf(json.optString("animationStyle", "PULSE"))
        )
    }
}

/** Kuralları SharedPreferences içinde JSON dizisi olarak saklar. */
object RulesRepository {
    private const val PREFS = "edge_lighting_prefs"
    private const val KEY_RULES = "notification_rules"

    fun getRules(context: android.content.Context): List<NotificationRule> {
        val prefs = context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_RULES, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            (0 until array.length()).map { NotificationRule.fromJson(array.getJSONObject(it)) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveRules(context: android.content.Context, rules: List<NotificationRule>) {
        val array = JSONArray()
        rules.forEach { array.put(it.toJson()) }
        context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE)
            .edit().putString(KEY_RULES, array.toString()).apply()
    }

    fun addRule(context: android.content.Context, rule: NotificationRule) {
        saveRules(context, getRules(context) + rule)
    }

    fun deleteRule(context: android.content.Context, ruleId: String) {
        saveRules(context, getRules(context).filterNot { it.id == ruleId })
    }
}
