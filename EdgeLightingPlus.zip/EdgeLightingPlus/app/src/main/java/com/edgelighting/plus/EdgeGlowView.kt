package com.edgelighting.plus

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.util.TypedValue
import android.view.View
import android.view.animation.LinearInterpolator

/**
 * Draws a pulsing glow around the four screen edges. One instance is
 * created per notification and destroyed when its animation ends.
 */
class EdgeGlowView(
    context: Context,
    private val color: Int,
    thicknessDp: Int
) : View(context) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var alphaFraction = 0f
    private var animator: ValueAnimator? = null

    private val thicknessPx = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, thicknessDp.toFloat(), resources.displayMetrics
    )

    fun start(durationMs: Long, onFinished: () -> Unit) {
        val pulse = ValueAnimator.ofFloat(0f, 1f, 1f, 0f).apply {
            duration = durationMs
            interpolator = LinearInterpolator()
            addUpdateListener {
                alphaFraction = it.animatedValue as Float
                invalidate()
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    onFinished()
                }
            })
        }
        animator = pulse
        pulse.start()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        animator?.cancel()
        animator = null
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val edgeAlpha = (Color.alpha(color) * alphaFraction).toInt().coerceIn(0, 255)
        val edgeColor = Color.argb(edgeAlpha, Color.red(color), Color.green(color), Color.blue(color))
        val transparent = Color.argb(0, Color.red(color), Color.green(color), Color.blue(color))

        // Top
        paint.shader = LinearGradient(0f, 0f, 0f, thicknessPx, edgeColor, transparent, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, thicknessPx, paint)
        // Bottom
        paint.shader = LinearGradient(0f, h, 0f, h - thicknessPx, edgeColor, transparent, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, h - thicknessPx, w, h, paint)
        // Left
        paint.shader = LinearGradient(0f, 0f, thicknessPx, 0f, edgeColor, transparent, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, thicknessPx, h, paint)
        // Right
        paint.shader = LinearGradient(w, 0f, w - thicknessPx, 0f, edgeColor, transparent, Shader.TileMode.CLAMP)
        canvas.drawRect(w - thicknessPx, 0f, w, h, paint)
    }
}
