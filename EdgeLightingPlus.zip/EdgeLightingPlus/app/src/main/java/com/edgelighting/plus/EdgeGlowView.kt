package com.edgelighting.plus

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import android.util.TypedValue
import android.view.View
import android.view.animation.LinearInterpolator

/**
 * PULSE efekti: ekranın yuvarlak köşelerini saran, renk geçişli (gökkuşağı
 * tonlarında), yumuşak parlayan bir çerçeve — kullanıcının seçtiği rengin
 * etrafında dönen bir gradient ile.
 */
class EdgeGlowView(
    context: Context,
    private val color: Int,
    thicknessDp: Int
) : View(context), EdgeEffect {

    init {
        // BlurMaskFilter donanım hızlandırmalı katmanda çalışmaz.
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    private val thicknessPx = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, thicknessDp.toFloat(), resources.displayMetrics
    )
    private val cornerRadiusPx = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, 48f, resources.displayMetrics
    )
    private val blurRadiusPx = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, 10f, resources.displayMetrics
    )

    private val sharpPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = thicknessPx
        strokeCap = Paint.Cap.ROUND
    }
    private val softPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = thicknessPx * 2.2f
        strokeCap = Paint.Cap.ROUND
        maskFilter = BlurMaskFilter(blurRadiusPx, BlurMaskFilter.Blur.NORMAL)
    }

    private val palette = buildPalette(color)
    private val rotationMatrix = Matrix()

    private var alphaFraction = 0f
    private var rotationDegrees = 0f
    private var animator: ValueAnimator? = null

    override fun start(durationMs: Long, onFinished: () -> Unit) {
        val anim = ValueAnimator.ofFloat(0f, 1f, 1f, 0f).apply {
            duration = durationMs
            interpolator = LinearInterpolator()
            addUpdateListener {
                alphaFraction = it.animatedValue as Float
                rotationDegrees += 3.2f
                invalidate()
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    onFinished()
                }
            })
        }
        animator = anim
        anim.start()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        animator?.cancel()
        animator = null
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val inset = thicknessPx
        val rect = RectF(inset, inset, w - inset, h - inset)

        val cx = w / 2f
        val cy = h / 2f
        val radius = kotlin.math.hypot(w, h) / 2f
        val shader = SweepGradient(cx, cy, palette, null)
        rotationMatrix.setRotate(rotationDegrees, cx, cy)
        shader.setLocalMatrix(rotationMatrix)

        val alpha = (255 * alphaFraction).toInt().coerceIn(0, 255)
        sharpPaint.shader = shader
        sharpPaint.alpha = alpha
        softPaint.shader = shader
        softPaint.alpha = (alpha * 0.55f).toInt()

        canvas.drawRoundRect(rect, cornerRadiusPx, cornerRadiusPx, softPaint)
        canvas.drawRoundRect(rect, cornerRadiusPx, cornerRadiusPx, sharpPaint)
    }

    companion object {
        /** Seçilen rengin etrafında, aynı tondan çeşitlenen döngüsel bir palet üretir. */
        private fun buildPalette(baseColor: Int): IntArray {
            val hsv = FloatArray(3)
            Color.colorToHSV(baseColor, hsv)
            val hue = hsv[0]
            val sat = hsv[1].coerceAtLeast(0.6f)
            val value = hsv[2].coerceAtLeast(0.9f)
            val offsets = floatArrayOf(0f, 35f, 70f, 35f, 0f, -35f, -70f, -35f, 0f)
            return offsets.map { offset ->
                val h = ((hue + offset) % 360f + 360f) % 360f
                Color.HSVToColor(floatArrayOf(h, sat, value))
            }.toIntArray()
        }
    }
}
