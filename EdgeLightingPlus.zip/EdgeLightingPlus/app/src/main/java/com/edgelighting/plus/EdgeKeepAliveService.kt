package com.edgelighting.plus

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * Düşük öncelikli, sessiz bir foreground service. Tek amacı: uygulamanın
 * süreci (process) hiç Activity açık olmasa bile canlı kalsın, böylece aynı
 * süreçte çalışan EdgeLightingService (bildirim dinleyici) de OEM'lerin
 * agresif "uygulamayı arka planda kapat" davranışına karşı daha dayanıklı
 * olsun. Bu, "sadece uygulama ekranda açıkken çalışıyor" sorununun ana
 * çözümüdür — bildirim dinleyicisi teknik olarak arka planda da çalışması
 * gerekirken, işlemin tamamen öldürülmesi bunu engelliyordu.
 */
class EdgeKeepAliveService : Service() {

    override fun onCreate() {
        super.onCreate()
        createChannelIfNeeded()
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.keep_alive_notification_text))
            .setSmallIcon(android.R.drawable.presence_online)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .setShowWhen(false)
            .build()
        startForeground(NOTIFICATION_ID, notification)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Sistem servisi öldürürse, mümkün olduğunda otomatik yeniden başlat.
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannelIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            if (manager.getNotificationChannel(CHANNEL_ID) == null) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    getString(R.string.keep_alive_channel_name),
                    NotificationManager.IMPORTANCE_MIN
                ).apply {
                    description = getString(R.string.keep_alive_channel_description)
                    setShowBadge(false)
                }
                manager.createNotificationChannel(channel)
            }
        }
    }

    companion object {
        const val CHANNEL_ID = "edge_lighting_keepalive"
        const val NOTIFICATION_ID = 1001

        fun start(context: Context) {
            val intent = Intent(context, EdgeKeepAliveService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }
}
