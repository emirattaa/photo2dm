package com.edgelighting.plus

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Cihaz yeniden başladığında keep-alive servisini otomatik başlatır. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val enabledListeners = android.provider.Settings.Secure.getString(
                context.contentResolver, "enabled_notification_listeners"
            )
            val hasAccess = enabledListeners?.contains(context.packageName) == true
            if (hasAccess) {
                EdgeKeepAliveService.start(context)
            }
        }
    }
}
