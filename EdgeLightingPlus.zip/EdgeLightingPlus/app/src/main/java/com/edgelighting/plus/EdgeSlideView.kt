package com.edgelighting.plus

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.util.TypedValue
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator

/**
 * SLIDE efekti ("geliş animasyonu"): dört kenar boyunca kayan parlak bir
 * ışık şeridi — üstten/alttan soldan sağa, sol/sağdan yukarıdan aşağıya.
 */
class EdgeSlideView(
    context: Context,
    private val color: Int,
    thicknessDp: Int
) : View(context), EdgeEffect {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var progress = 0f
    private var animator: ValueAnimator? = null

    private val thicknessPx = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, thicknessDp.toFloat(), resources.displayMetrics
    )

    override fun start(durationMs: Long, onFinished: () -> Unit) {
        val anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = durationMs
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener {
                progress = it.animatedValue as Float
                invalidate()
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    onFinished()
                }
            })
        }
        animator = anim
        anim.start()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        animator?.cancel()
        animator = null
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val cometLength = w * 0.35f
        val cometLengthV = h * 0.35f

        // Üst kenar: soldan sağa
        drawHorizontalComet(canvas, y = 0f, thickness = thicknessPx, totalWidth = w, cometLength = cometLength)
        // Alt kenar: sağdan sola
        drawHorizontalComet(canvas, y = h - thicknessPx, thickness = thicknessPx, totalWidth = w, cometLength = cometLength, reversed = true)
        // Sol kenar: yukarıdan aşağıya
        drawVerticalComet(canvas, x = 0f, thickness = thicknessPx, totalHeight = h, cometLength = cometLengthV)
        // Sağ kenar: aşağıdan yukarıya
        drawVerticalComet(canvas, x = w - thicknessPx, thickness = thicknessPx, totalHeight = h, cometLength = cometLengthV, reversed = true)
    }

    private fun drawHorizontalComet(canvas: Canvas, y: Float, thickness: Float, totalWidth: Float, cometLength: Float, reversed: Boolean = false) {
        val travel = totalWidth + cometLength
        val head = if (!reversed) -cometLength + progress * travel else totalWidth + cometLength - progress * travel
        val tail = if (!reversed) head - cometLength else head + cometLength
        val start = minOf(head, tail).coerceIn(0f, totalWidth)
        val end = maxOf(head, tail).coerceIn(0f, totalWidth)
        if (end <= start) return

        val transparent = Color.argb(0, Color.red(color), Color.green(color), Color.blue(color))
        paint.shader = if (!reversed)
            LinearGradient(start, 0f, end, 0f, transparent, color, Shader.TileMode.CLAMP)
        else
            LinearGradient(start, 0f, end, 0f, color, transparent, Shader.TileMode.CLAMP)
        canvas.drawRect(start, y, end, y + thickness, paint)
    }

    private fun drawVerticalComet(canvas: Canvas, x: Float, thickness: Float, totalHeight: Float, cometLength: Float, reversed: Boolean = false) {
        val travel = totalHeight + cometLength
        val head = if (!reversed) -cometLength + progress * travel else totalHeight + cometLength - progress * travel
        val tail = if (!reversed) head - cometLength else head + cometLength
        val start = minOf(head, tail).coerceIn(0f, totalHeight)
        val end = maxOf(head, tail).coerceIn(0f, totalHeight)
        if (end <= start) return

        val transparent = Color.argb(0, Color.red(color), Color.green(color), Color.blue(color))
        paint.shader = if (!reversed)
            LinearGradient(0f, start, 0f, end, transparent, color, Shader.TileMode.CLAMP)
        else
            LinearGradient(0f, start, 0f, end, color, transparent, Shader.TileMode.CLAMP)
        canvas.drawRect(x, start, x + thickness, end, paint)
    }
}
