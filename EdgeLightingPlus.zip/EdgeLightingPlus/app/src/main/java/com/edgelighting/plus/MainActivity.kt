package com.edgelighting.plus

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.edgelighting.plus.databinding.ActivityMainBinding
import com.google.android.material.card.MaterialCardView

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val colorSwatches = listOf(
        0xFF2196F3.toInt(), // blue
        0xFF00E676.toInt(), // green
        0xFFFF1744.toInt(), // red
        0xFFFFC400.toInt(), // amber
        0xFFD500F9.toInt(), // purple
        0xFF00E5FF.toInt()  // cyan
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        refreshColorSwatches()
        setupDurationSlider()
        setupButtons()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun swatchViews(): List<MaterialCardView> = listOf(
        binding.swatch1, binding.swatch2, binding.swatch3,
        binding.swatch4, binding.swatch5, binding.swatch6
    )

    private fun refreshColorSwatches() {
        val currentColor = SettingsPrefs.getColor(this)
        swatchViews().forEachIndexed { index, view ->
            val color = colorSwatches[index]
            view.setCardBackgroundColor(color)
            view.strokeWidth = if (color == currentColor) 8 else 0
            view.strokeColor = Color.WHITE
            view.setOnClickListener {
                SettingsPrefs.setColor(this, color)
                refreshColorSwatches()
            }
        }
    }

    private fun setupDurationSlider() {
        val durationMs = SettingsPrefs.getDurationMs(this).toInt()
        binding.durationSeekBar.max = 6000
        binding.durationSeekBar.progress = durationMs
        updateDurationLabel(durationMs)

        binding.durationSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val clamped = progress.coerceAtLeast(500)
                updateDurationLabel(clamped)
                if (fromUser) SettingsPrefs.setDurationMs(this@MainActivity, clamped)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun updateDurationLabel(durationMs: Int) {
        binding.durationValueText.text = getString(R.string.duration_value, durationMs / 1000f)
    }

    private fun setupButtons() {
        binding.grantNotificationAccessButton.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        binding.grantOverlayButton.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
        }

        binding.testButton.setOnClickListener {
            EdgeOverlayManager.enqueue(
                applicationContext,
                SettingsPrefs.getColor(this),
                SettingsPrefs.getDurationMs(this),
                SettingsPrefs.getThicknessDp(this)
            )
        }

        binding.testTwiceButton.setOnClickListener {
            // Fires two glows back-to-back — proves the queue fix works:
            // the second glow now plays right after the first finishes.
            val color = SettingsPrefs.getColor(this)
            val duration = SettingsPrefs.getDurationMs(this)
            val thickness = SettingsPrefs.getThicknessDp(this)
            EdgeOverlayManager.enqueue(applicationContext, color, duration, thickness)
            EdgeOverlayManager.enqueue(applicationContext, Color.WHITE, duration, thickness)
            Toast.makeText(this, R.string.test_twice_hint, Toast.LENGTH_SHORT).show()
        }
    }

    private fun refreshStatus() {
        val notifGranted = isNotificationAccessGranted()
        val overlayGranted = Settings.canDrawOverlays(this)

        binding.notificationStatusText.text =
            getString(if (notifGranted) R.string.status_granted else R.string.status_missing)
        binding.overlayStatusText.text =
            getString(if (overlayGranted) R.string.status_granted else R.string.status_missing)

        binding.grantNotificationAccessButton.isEnabled = !notifGranted
        binding.grantOverlayButton.isEnabled = !overlayGranted
        binding.testButton.isEnabled = notifGranted && overlayGranted
        binding.testTwiceButton.isEnabled = notifGranted && overlayGranted
    }

    private fun isNotificationAccessGranted(): Boolean {
        val enabledListeners = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return enabledListeners?.contains(packageName) == true
    }
}
