package com.edgelighting.plus

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.LayoutInflater
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.edgelighting.plus.databinding.ActivityMainBinding
import com.google.android.material.card.MaterialCardView

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val colorSwatches = listOf(
        0xFF2196F3.toInt(), // blue
        0xFF00E676.toInt(), // green
        0xFFFF1744.toInt(), // red
        0xFFFFC400.toInt(), // amber
        0xFFD500F9.toInt(), // purple
        0xFF00E5FF.toInt()  // cyan
    )

    // Kural ekleme dialog'unda seçilen renk (varsayılan ilk swatch).
    private var pendingDialogColor = colorSwatches[0]

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* sonuç önemli değil, servis yine de başlar */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        refreshColorSwatches()
        setupDurationSlider()
        setupDefaultAnimationSelector()
        setupButtons()
        refreshRulesList()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        if (isNotificationAccessGranted()) {
            ensureKeepAliveService()
        }
    }

    private fun ensureKeepAliveService() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
        EdgeKeepAliveService.start(this)
    }

    // ---------- Renk seçimi (varsayılan görünüm) ----------

    private fun swatchViews(): List<MaterialCardView> = listOf(
        binding.swatch1, binding.swatch2, binding.swatch3,
        binding.swatch4, binding.swatch5, binding.swatch6
    )

    private fun refreshColorSwatches() {
        val currentColor = SettingsPrefs.getColor(this)
        swatchViews().forEachIndexed { index, view ->
            val color = colorSwatches[index]
            view.setCardBackgroundColor(color)
            view.strokeWidth = if (color == currentColor) 8 else 0
            view.strokeColor = Color.WHITE
            view.setOnClickListener {
                SettingsPrefs.setColor(this, color)
                refreshColorSwatches()
            }
        }
    }

    private fun setupDurationSlider() {
        val durationMs = SettingsPrefs.getDurationMs(this).toInt()
        binding.durationSeekBar.max = 6000
        binding.durationSeekBar.progress = durationMs
        updateDurationLabel(durationMs)

        binding.durationSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val clamped = progress.coerceAtLeast(500)
                updateDurationLabel(clamped)
                if (fromUser) SettingsPrefs.setDurationMs(this@MainActivity, clamped)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun updateDurationLabel(durationMs: Int) {
        binding.durationValueText.text = getString(R.string.duration_value, durationMs / 1000f)
    }

    private fun setupDefaultAnimationSelector() {
        val current = SettingsPrefs.getDefaultAnimation(this)
        when (current) {
            AnimationStyle.PULSE -> binding.radioDefaultPulse.isChecked = true
            AnimationStyle.HEARTS -> binding.radioDefaultHearts.isChecked = true
            AnimationStyle.SLIDE -> binding.radioDefaultSlide.isChecked = true
        }
        binding.defaultAnimationRadioGroup.setOnCheckedChangeListener { _, checkedId ->
            val style = when (checkedId) {
                binding.radioDefaultHearts.id -> AnimationStyle.HEARTS
                binding.radioDefaultSlide.id -> AnimationStyle.SLIDE
                else -> AnimationStyle.PULSE
            }
            SettingsPrefs.setDefaultAnimation(this, style)
        }
    }

    // ---------- Kurallar (rules) ----------

    private fun refreshRulesList() {
        binding.rulesContainer.removeAllViews()
        val rules = RulesRepository.getRules(this)
        if (rules.isEmpty()) {
            val empty = TextView(this).apply {
                text = "Henüz kural eklenmedi. Tüm bildirimler varsayılan görünümle tetiklenir."
                setTextColor(Color.parseColor("#B0B0B0"))
                textSize = 12f
            }
            binding.rulesContainer.addView(empty)
            return
        }
        rules.forEach { rule -> addRuleRow(rule) }
    }

    private fun addRuleRow(rule: NotificationRule) {
        val row = layoutInflater.inflate(R.layout.item_rule, binding.rulesContainer, false)
        val colorDot = row.findViewById<android.view.View>(R.id.ruleColorDot)
        val descriptionText = row.findViewById<TextView>(R.id.ruleDescriptionText)
        val deleteButton = row.findViewById<com.google.android.material.button.MaterialButton>(R.id.deleteRuleButton)

        (colorDot.background.mutate() as android.graphics.drawable.GradientDrawable).setColor(rule.color)

        val fieldLabel = if (rule.field == RuleField.TITLE) "Başlık" else "Açıklama"
        val animLabel = when (rule.animationStyle) {
            AnimationStyle.PULSE -> "✨ Parlama"
            AnimationStyle.HEARTS -> "💗 Kalpler"
            AnimationStyle.SLIDE -> "⚡ Kayma"
        }
        descriptionText.text = "$fieldLabel içeriyor: \"${rule.keyword}\" → $animLabel"

        deleteButton.setOnClickListener {
            RulesRepository.deleteRule(this, rule.id)
            refreshRulesList()
        }

        binding.rulesContainer.addView(row)
    }

    private fun showAddRuleDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_rule, null)
        val fieldGroup = dialogView.findViewById<RadioGroup>(R.id.fieldRadioGroup)
        val keywordEditText = dialogView.findViewById<android.widget.EditText>(R.id.keywordEditText)
        val animationGroup = dialogView.findViewById<RadioGroup>(R.id.animationRadioGroup)

        val dialogSwatchViews = listOf(
            dialogView.findViewById<MaterialCardView>(R.id.dialogSwatch1),
            dialogView.findViewById<MaterialCardView>(R.id.dialogSwatch2),
            dialogView.findViewById<MaterialCardView>(R.id.dialogSwatch3),
            dialogView.findViewById<MaterialCardView>(R.id.dialogSwatch4),
            dialogView.findViewById<MaterialCardView>(R.id.dialogSwatch5),
            dialogView.findViewById<MaterialCardView>(R.id.dialogSwatch6)
        )

        pendingDialogColor = colorSwatches[0]

        fun refreshDialogSwatches() {
            dialogSwatchViews.forEachIndexed { index, view ->
                val color = colorSwatches[index]
                view.setCardBackgroundColor(color)
                view.strokeWidth = if (color == pendingDialogColor) 6 else 0
                view.strokeColor = Color.WHITE
                view.setOnClickListener {
                    pendingDialogColor = color
                    refreshDialogSwatches()
                }
            }
        }
        refreshDialogSwatches()

        AlertDialog.Builder(this)
            .setTitle("Yeni Kural")
            .setView(dialogView)
            .setPositiveButton("Kaydet") { _, _ ->
                val keyword = keywordEditText.text.toString().trim()
                if (keyword.isEmpty()) {
                    Toast.makeText(this, "Lütfen bir kelime girin", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val field = if (fieldGroup.checkedRadioButtonId == R.id.radioText) RuleField.TEXT else RuleField.TITLE
                val style = when (animationGroup.checkedRadioButtonId) {
                    R.id.radioHearts -> AnimationStyle.HEARTS
                    R.id.radioSlide -> AnimationStyle.SLIDE
                    else -> AnimationStyle.PULSE
                }
                val rule = NotificationRule(
                    id = System.currentTimeMillis().toString(),
                    field = field,
                    keyword = keyword,
                    color = pendingDialogColor,
                    animationStyle = style
                )
                RulesRepository.addRule(this, rule)
                refreshRulesList()
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    // ---------- İzinler / butonlar ----------

    private fun setupButtons() {
        binding.grantNotificationAccessButton.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        binding.grantOverlayButton.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
        }

        binding.ignoreBatteryOptButton.setOnClickListener {
            requestIgnoreBatteryOptimizations()
        }

        binding.addRuleButton.setOnClickListener {
            showAddRuleDialog()
        }

        binding.testButton.setOnClickListener {
            EdgeOverlayManager.enqueue(
                applicationContext,
                SettingsPrefs.getColor(this),
                SettingsPrefs.getDurationMs(this),
                SettingsPrefs.getThicknessDp(this),
                SettingsPrefs.getDefaultAnimation(this)
            )
        }

        binding.testTwiceButton.setOnClickListener {
            // Art arda iki farklı animasyon — kuyruğun ikisini de sırayla
            // oynattığını göstermek için.
            val duration = SettingsPrefs.getDurationMs(this)
            val thickness = SettingsPrefs.getThicknessDp(this)
            EdgeOverlayManager.enqueue(applicationContext, SettingsPrefs.getColor(this), duration, thickness, AnimationStyle.PULSE)
            EdgeOverlayManager.enqueue(applicationContext, 0xFFFF1744.toInt(), duration, thickness, AnimationStyle.HEARTS)
            Toast.makeText(this, R.string.test_twice_hint, Toast.LENGTH_SHORT).show()
        }
    }

    private fun requestIgnoreBatteryOptimizations() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (powerManager.isIgnoringBatteryOptimizations(packageName)) {
            Toast.makeText(this, "Pil optimizasyonu zaten kapalı", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            startActivity(
                Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")
                )
            )
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun refreshStatus() {
        val notifGranted = isNotificationAccessGranted()
        val overlayGranted = Settings.canDrawOverlays(this)

        binding.notificationStatusText.text =
            getString(if (notifGranted) R.string.status_granted else R.string.status_missing)
        binding.overlayStatusText.text =
            getString(if (overlayGranted) R.string.status_granted else R.string.status_missing)

        binding.grantNotificationAccessButton.isEnabled = !notifGranted
        binding.grantOverlayButton.isEnabled = !overlayGranted
        binding.testButton.isEnabled = notifGranted && overlayGranted
        binding.testTwiceButton.isEnabled = notifGranted && overlayGranted
    }

    private fun isNotificationAccessGranted(): Boolean {
        val enabledListeners = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return enabledListeners?.contains(packageName) == true
    }
}
