package com.edgelighting.plus

import android.content.Context

/**
 * Hangi uygulamaların kenar aydınlatmasını tetikleyebileceğini kontrol eder.
 * Liste boşsa: sistem/gürültü bildirimleri hariç TÜM uygulamalar tetikler
 * (varsayılan davranış). Liste doluysa: SADECE listedeki uygulamalar tetikler.
 */
object AppFilterRepository {
    private const val PREFS = "edge_lighting_prefs"
    private const val KEY_ALLOWED_PACKAGES = "allowed_packages"

    // Ekran görüntüsü, USB, medya kontrolü gibi gürültü üreten sistem
    // bileşenleri — kullanıcı ne seçerse seçsin bunlar asla tetiklemez.
    val ALWAYS_IGNORED_PACKAGES = setOf(
        "com.android.systemui",
        "android",
        "com.google.android.systemui"
    )

    fun getAllowedPackages(context: Context): Set<String> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getStringSet(KEY_ALLOWED_PACKAGES, emptySet()) ?: emptySet()
    }

    fun setAllowedPackages(context: Context, packages: Set<String>) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putStringSet(KEY_ALLOWED_PACKAGES, packages)
            .apply()
    }

    fun isPackageAllowed(context: Context, packageName: String): Boolean {
        if (packageName in ALWAYS_IGNORED_PACKAGES) return false
        val allowed = getAllowedPackages(context)
        // Liste boşsa herkese izin ver; doluysa sadece seçilenlere.
        return allowed.isEmpty() || packageName in allowed
    }
}
