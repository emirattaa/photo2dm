package com.edgelighting.plus

import android.content.Context

/**
 * VARSAYILAN DAVRANIŞ: TÜM uygulamalar tetikler (systemui gibi saf sistem
 * bileşenleri hariç). Kullanıcı isterse belirli uygulamaları HARİÇ
 * tutabilir (blocklist) — eskisi gibi "izin verilenler" listesi değil,
 * çünkü "her uygulamada çalışsın" varsayılanı budur.
 */
object AppFilterRepository {
    private const val PREFS = "edge_lighting_prefs"
    private const val KEY_BLOCKED_PACKAGES = "blocked_packages"

    // Ekran görüntüsü, USB, sistem arayüzü gibi bileşenler — kullanıcı ne
    // seçerse seçsin bunlar asla tetiklemez.
    val ALWAYS_IGNORED_PACKAGES = setOf(
        "com.android.systemui",
        "android",
        "com.google.android.systemui"
    )

    fun getBlockedPackages(context: Context): Set<String> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getStringSet(KEY_BLOCKED_PACKAGES, emptySet()) ?: emptySet()
    }

    fun setBlockedPackages(context: Context, packages: Set<String>) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putStringSet(KEY_BLOCKED_PACKAGES, packages)
            .apply()
    }

    fun isPackageAllowed(context: Context, packageName: String): Boolean {
        if (packageName in ALWAYS_IGNORED_PACKAGES) return false
        return packageName !in getBlockedPackages(context)
    }
}
