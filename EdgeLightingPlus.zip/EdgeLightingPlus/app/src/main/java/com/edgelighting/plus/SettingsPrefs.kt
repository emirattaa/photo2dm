package com.edgelighting.plus

import android.content.Context
import androidx.core.content.edit

object SettingsPrefs {
    private const val PREFS = "edge_lighting_prefs"
    private const val KEY_COLOR = "edge_color"
    private const val KEY_DURATION = "edge_duration"
    private const val KEY_THICKNESS = "edge_thickness"
    private const val KEY_ANIMATION = "edge_animation"

    private const val DEFAULT_COLOR = 0xFF2196F3.toInt()
    private const val DEFAULT_DURATION_MS = 2500
    private const val DEFAULT_THICKNESS_DP = 10

    fun getColor(context: Context): Int =
        prefs(context).getInt(KEY_COLOR, DEFAULT_COLOR)

    fun setColor(context: Context, color: Int) {
        prefs(context).edit { putInt(KEY_COLOR, color) }
    }

    fun getDurationMs(context: Context): Long =
        prefs(context).getInt(KEY_DURATION, DEFAULT_DURATION_MS).toLong()

    fun setDurationMs(context: Context, durationMs: Int) {
        prefs(context).edit { putInt(KEY_DURATION, durationMs) }
    }

    fun getThicknessDp(context: Context): Int =
        prefs(context).getInt(KEY_THICKNESS, DEFAULT_THICKNESS_DP)

    fun setThicknessDp(context: Context, thicknessDp: Int) {
        prefs(context).edit { putInt(KEY_THICKNESS, thicknessDp) }
    }

    fun getDefaultAnimation(context: Context): AnimationStyle =
        AnimationStyle.valueOf(prefs(context).getString(KEY_ANIMATION, AnimationStyle.PULSE.name)!!)

    fun setDefaultAnimation(context: Context, style: AnimationStyle) {
        prefs(context).edit { putString(KEY_ANIMATION, style.name) }
    }

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
