package com.edgelighting.plus

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager

/**
 * Renders the edge-glow overlay ONE notification at a time via a FIFO queue.
 *
 * This is the fix for the classic "stacking" bug: without a queue, a second
 * notification arriving while the first glow is still animating either gets
 * dropped or tries to add a second overlay view on top of the first (which
 * either crashes silently or just never becomes visible). Here, every
 * incoming notification is appended to the queue; only when the current
 * animation finishes and its view is fully removed does the next item start.
 */
object EdgeOverlayManager {

    private data class QueueItem(val color: Int, val durationMs: Long, val thicknessDp: Int)

    private val queue = ArrayDeque<QueueItem>()
    private var isShowing = false
    private val mainHandler = Handler(Looper.getMainLooper())

    @Synchronized
    fun enqueue(context: Context, color: Int, durationMs: Long, thicknessDp: Int) {
        queue.addLast(QueueItem(color, durationMs, thicknessDp))
        tryShowNext(context.applicationContext)
    }

    @Synchronized
    private fun tryShowNext(context: Context) {
        if (isShowing) return
        val next = queue.removeFirstOrNull() ?: return
        isShowing = true
        mainHandler.post { render(context, next) }
    }

    private fun render(context: Context, item: QueueItem) {
        val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val glowView = EdgeGlowView(context, item.color, item.thicknessDp)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        try {
            windowManager.addView(glowView, params)
        } catch (e: Exception) {
            // Missing "draw over other apps" permission, or similar.
            finishCurrentAndAdvance(context)
            return
        }

        glowView.start(item.durationMs) {
            try {
                windowManager.removeView(glowView)
            } catch (_: Exception) {
                // Already detached — safe to ignore.
            }
            finishCurrentAndAdvance(context)
        }
    }

    @Synchronized
    private fun finishCurrentAndAdvance(context: Context) {
        isShowing = false
        tryShowNext(context)
    }
}
