package com.edgelighting.plus

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager

/**
 * Renders the edge overlay ONE notification at a time via a FIFO queue.
 *
 * Bu, "ikinci bildirim gelmiyor" sorununun uygulama-içi kısmının çözümü:
 * aynı anda birden fazla efekt üst üste eklenmez, kuyruğa girer ve
 * öncekinin animasyonu bitip view'i kaldırılınca sıradaki başlar.
 * (Uygulamanın kendisi hiç açılmıyor/tetiklenmiyor gibi görünüyorsa bu artık
 * kuyruktan değil, işletim sisteminin dinleyici servisini pil optimizasyonu
 * yüzünden koparmasından kaynaklanır — bkz. EdgeLightingService.)
 */
object EdgeOverlayManager {

    private data class QueueItem(
        val color: Int,
        val durationMs: Long,
        val thicknessDp: Int,
        val style: AnimationStyle
    )

    private val queue = ArrayDeque<QueueItem>()
    private var isShowing = false
    private val mainHandler = Handler(Looper.getMainLooper())

    @Synchronized
    fun enqueue(context: Context, color: Int, durationMs: Long, thicknessDp: Int, style: AnimationStyle) {
        queue.addLast(QueueItem(color, durationMs, thicknessDp, style))
        tryShowNext(context.applicationContext)
    }

    @Synchronized
    private fun tryShowNext(context: Context) {
        if (isShowing) return
        val next = queue.removeFirstOrNull() ?: return
        isShowing = true
        mainHandler.post { render(context, next) }
    }

    private fun render(context: Context, item: QueueItem) {
        val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val view: View = when (item.style) {
            AnimationStyle.PULSE -> EdgeGlowView(context, item.color, item.thicknessDp)
            AnimationStyle.HEARTS -> EdgeHeartsView(context, item.color)
            AnimationStyle.SLIDE -> EdgeSlideView(context, item.color, item.thicknessDp)
        }
        val effect = view as EdgeEffect

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        try {
            windowManager.addView(view, params)
        } catch (e: Exception) {
            finishCurrentAndAdvance(context)
            return
        }

        effect.start(item.durationMs) {
            try {
                windowManager.removeView(view)
            } catch (_: Exception) {
                // Zaten kaldırılmış olabilir, güvenle yok sayılır.
            }
            finishCurrentAndAdvance(context)
        }
    }

    @Synchronized
    private fun finishCurrentAndAdvance(context: Context) {
        isShowing = false
        tryShowNext(context)
    }
}
