package com.edgelighting.plus

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.TypedValue
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.sin
import kotlin.random.Random

/**
 * HEARTS efekti: ekranın alt kenarından yukarı doğru süzülen, hafifçe
 * sağa sola sallanan kalpler + altta hafif bir glow şeridi.
 */
class EdgeHeartsView(
    context: Context,
    private val color: Int,
    private val heartCount: Int = 10
) : View(context), EdgeEffect {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = this@EdgeHeartsView.color }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var animator: ValueAnimator? = null
    private var progress = 0f

    private val random = Random(System.currentTimeMillis())
    private data class Heart(val xFraction: Float, val delay: Float, val size: Float, val sway: Float)
    private val hearts = List(heartCount) {
        Heart(
            xFraction = random.nextFloat(),
            delay = random.nextFloat() * 0.5f,
            size = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, (14 + random.nextInt(14)).toFloat(), resources.displayMetrics),
            sway = 20f + random.nextFloat() * 40f
        )
    }

    override fun start(durationMs: Long, onFinished: () -> Unit) {
        val anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = durationMs
            interpolator = LinearInterpolator()
            addUpdateListener {
                progress = it.animatedValue as Float
                invalidate()
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    onFinished()
                }
            })
        }
        animator = anim
        anim.start()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        animator?.cancel()
        animator = null
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        // Alt kenarda hafif bir glow şeridi
        val baseAlpha = (120 * (1f - kotlin.math.abs(progress - 0.5f) * 2f)).toInt().coerceIn(0, 120)
        glowPaint.color = Color.argb(baseAlpha, Color.red(color), Color.green(color), Color.blue(color))
        canvas.drawRect(0f, h - 24f, w, h, glowPaint)

        hearts.forEach { heart ->
            val local = ((progress - heart.delay) / (1f - heart.delay)).coerceIn(0f, 1f)
            if (local <= 0f) return@forEach
            val y = h - local * (h * 0.9f)
            val x = heart.xFraction * w + sin((local * 6f).toDouble()).toFloat() * heart.sway
            val alpha = (255 * (1f - local) * (if (local < 0.15f) local / 0.15f else 1f)).toInt().coerceIn(0, 255)
            paint.alpha = alpha
            drawHeart(canvas, x, y, heart.size)
        }
    }

    private fun drawHeart(canvas: Canvas, cx: Float, cy: Float, s: Float) {
        val path = Path()
        path.moveTo(cx, cy + s * 0.3f)
        path.cubicTo(cx - s, cy - s * 0.4f, cx - s * 0.5f, cy - s, cx, cy - s * 0.3f)
        path.cubicTo(cx + s * 0.5f, cy - s, cx + s, cy - s * 0.4f, cx, cy + s * 0.3f)
        path.close()
        canvas.drawPath(path, paint)
    }
}
