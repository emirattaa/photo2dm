package com.edgelighting.plus

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.TypedValue
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.sin
import kotlin.random.Random

/**
 * HEARTS efekti: kalpler ekranın ÜSTÜNDEN belirip yumuşak bir sallanışla
 * aşağı doğru düşer, düşerken hafifçe döner ve büyür/küçülür, sona doğru
 * solur. Her kalbin arkasında hafif bir parıltı (glow) katmanı var.
 */
class EdgeHeartsView(
    context: Context,
    private val color: Int,
    heartCount: Int = 14
) : View(context), EdgeEffect {

    private val heartPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = this@EdgeHeartsView.color }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(70, Color.red(this@EdgeHeartsView.color), Color.green(this@EdgeHeartsView.color), Color.blue(this@EdgeHeartsView.color))
    }
    private val topFadePaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private var animator: ValueAnimator? = null
    private var progress = 0f

    private val random = Random(System.currentTimeMillis())

    private data class Heart(
        val xFraction: Float,
        val delay: Float,        // 0f..0.5f, kademeli başlangıç
        val fallDuration: Float, // toplam animasyonun ne kadarında düşecek (0.5f..1f)
        val size: Float,
        val sway: Float,
        val swayPhase: Float,
        val baseRotation: Float,
        val rotationAmount: Float
    )

    private val hearts = List(heartCount) {
        Heart(
            xFraction = 0.05f + random.nextFloat() * 0.9f,
            delay = random.nextFloat() * 0.45f,
            fallDuration = 0.55f + random.nextFloat() * 0.35f,
            size = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, (12 + random.nextInt(16)).toFloat(), resources.displayMetrics),
            sway = 16f + random.nextFloat() * 34f,
            swayPhase = random.nextFloat() * 6.28f,
            baseRotation = -20f + random.nextFloat() * 40f,
            rotationAmount = 10f + random.nextFloat() * 20f
        )
    }

    override fun start(durationMs: Long, onFinished: () -> Unit) {
        val anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = durationMs
            interpolator = LinearInterpolator()
            addUpdateListener {
                progress = it.animatedValue as Float
                invalidate()
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    onFinished()
                }
            })
        }
        animator = anim
        anim.start()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        animator?.cancel()
        animator = null
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        // Üst kenarda kalplerin "belirdiği" yumuşak bir ışık şeridi.
        val topAlpha = (110 * (1f - progress)).toInt().coerceIn(0, 110)
        topFadePaint.color = Color.argb(topAlpha, Color.red(color), Color.green(color), Color.blue(color))
        canvas.drawRect(0f, 0f, w, h * 0.06f, topFadePaint)

        hearts.forEach { heart ->
            val local = ((progress - heart.delay) / heart.fallDuration).coerceIn(0f, 1f)
            if (local <= 0f || (progress - heart.delay) < 0f) return@forEach

            // Yerçekimi hissi için ease-in eğrisi (yavaş başlar, hızlanır).
            val eased = local * local

            val y = -heart.size + eased * (h + heart.size * 2f)
            val x = (heart.xFraction * w) + sin(eased * 5f + heart.swayPhase) * heart.sway
            val rotation = heart.baseRotation + sin(eased * 4f + heart.swayPhase) * heart.rotationAmount
            val scale = 0.85f + 0.3f * sin((eased * 3.14f).coerceAtMost(3.14f))

            val fadeIn = (local / 0.12f).coerceIn(0f, 1f)
            val fadeOut = ((1f - local) / 0.2f).coerceIn(0f, 1f)
            val alpha = (255 * fadeIn * fadeOut).toInt().coerceIn(0, 255)
            if (alpha <= 0) return@forEach

            heartPaint.alpha = alpha
            glowPaint.alpha = (alpha * 0.5f).toInt()

            canvas.save()
            canvas.translate(x, y)
            canvas.rotate(rotation)
            canvas.scale(scale, scale)
            drawHeart(canvas, 0f, 0f, heart.size * 1.6f, glowPaint)
            drawHeart(canvas, 0f, 0f, heart.size, heartPaint)
            canvas.restore()
        }
    }

    private fun drawHeart(canvas: Canvas, cx: Float, cy: Float, s: Float, paint: Paint) {
        val path = Path()
        path.moveTo(cx, cy + s * 0.32f)
        path.cubicTo(cx - s, cy - s * 0.4f, cx - s * 0.5f, cy - s, cx, cy - s * 0.28f)
        path.cubicTo(cx + s * 0.5f, cy - s, cx + s, cy - s * 0.4f, cx, cy + s * 0.32f)
        path.close()
        canvas.drawPath(path, paint)
    }
}
