package com.edgelighting.plus

import android.app.Notification
import android.content.ComponentName
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

class EdgeLightingService : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        super.onNotificationPosted(sbn)

        if (sbn.packageName == packageName) return
        if (!shouldTrigger(sbn)) return
        if (!AppFilterRepository.isPackageAllowed(applicationContext, sbn.packageName)) return

        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = (extras.getCharSequence(Notification.EXTRA_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_BIG_TEXT))?.toString() ?: ""

        val rules = RulesRepository.getRules(applicationContext)
        val matchedRules = rules.filter { it.matches(title, text) }

        if (matchedRules.isNotEmpty()) {
            matchedRules.forEach { rule ->
                EdgeOverlayManager.enqueue(
                    applicationContext,
                    rule.color,
                    SettingsPrefs.getDurationMs(applicationContext),
                    SettingsPrefs.getThicknessDp(applicationContext),
                    rule.animationStyle
                )
            }
        } else {
            EdgeOverlayManager.enqueue(
                applicationContext,
                SettingsPrefs.getColor(applicationContext),
                SettingsPrefs.getDurationMs(applicationContext),
                SettingsPrefs.getThicknessDp(applicationContext),
                SettingsPrefs.getDefaultAnimation(applicationContext)
            )
        }
    }

    /**
     * Ekran görüntüsü bildirimi, medya oynatma kontrolleri, grup özetleri
     * ve sürmekte olan (ongoing) bildirimler gibi "gürültü" olayları eler.
     * Bunlar gerçek bir mesaj/uyarı değildir ve tetiklenmemesi gerekir.
     */
    private fun shouldTrigger(sbn: StatusBarNotification): Boolean {
        val notification = sbn.notification

        if (sbn.isOngoing) return false
        if (notification.flags and Notification.FLAG_GROUP_SUMMARY != 0) return false
        if (notification.flags and Notification.FLAG_LOCAL_ONLY != 0) return false
        if (notification.flags and Notification.FLAG_FOREGROUND_SERVICE != 0) return false

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            when (notification.category) {
                Notification.CATEGORY_TRANSPORT, // medya oynatma kontrolleri
                Notification.CATEGORY_SERVICE,
                Notification.CATEGORY_PROGRESS -> return false
            }
        }

        return true
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        Log.d("EdgeLightingService", "Listener connected")
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        Log.d("EdgeLightingService", "Listener disconnected, requesting rebind")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            requestRebind(ComponentName(this, EdgeLightingService::class.java))
        }
    }
}
