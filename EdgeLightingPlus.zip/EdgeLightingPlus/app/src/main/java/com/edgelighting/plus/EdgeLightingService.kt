package com.edgelighting.plus

import android.app.Notification
import android.content.ComponentName
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

class EdgeLightingService : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        super.onNotificationPosted(sbn)

        if (sbn.packageName == packageName) return
        if (sbn.isOngoing) return

        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = (extras.getCharSequence(Notification.EXTRA_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_BIG_TEXT))?.toString() ?: ""

        val rules = RulesRepository.getRules(applicationContext)
        val matchedRules = rules.filter { it.matches(title, text) }

        if (matchedRules.isNotEmpty()) {
            // Birden fazla kural eşleşirse hepsi sırayla (kuyrukta) tetiklenir.
            matchedRules.forEach { rule ->
                EdgeOverlayManager.enqueue(
                    applicationContext,
                    rule.color,
                    SettingsPrefs.getDurationMs(applicationContext),
                    SettingsPrefs.getThicknessDp(applicationContext),
                    rule.animationStyle
                )
            }
        } else {
            // Hiçbir kural eşleşmediyse varsayılan görünümle tetikle.
            EdgeOverlayManager.enqueue(
                applicationContext,
                SettingsPrefs.getColor(applicationContext),
                SettingsPrefs.getDurationMs(applicationContext),
                SettingsPrefs.getThicknessDp(applicationContext),
                SettingsPrefs.getDefaultAnimation(applicationContext)
            )
        }
    }

    // --- OEM pil optimizasyonu servisin bağlantısını kopardığında otomatik
    // yeniden bağlanma isteği gönderir. Samsung/Xiaomi/Huawei gibi
    // üreticiler kullanılmayan dinleyicileri agresifçe kapatabiliyor;
    // requestRebind bu durumdan kurtulmaya çalışır. Kalıcı çözüm için
    // kullanıcının pil optimizasyonunu bu uygulama için kapatması gerekir
    // (uygulama içindeki "Pil Optimizasyonunu Kapat" butonuna bakın).
    override fun onListenerConnected() {
        super.onListenerConnected()
        Log.d("EdgeLightingService", "Listener connected")
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        Log.d("EdgeLightingService", "Listener disconnected, requesting rebind")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            requestRebind(ComponentName(this, EdgeLightingService::class.java))
        }
    }
}
