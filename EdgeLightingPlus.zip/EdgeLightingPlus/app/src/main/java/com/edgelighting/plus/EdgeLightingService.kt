package com.edgelighting.plus

import android.app.Notification
import android.app.NotificationManager
import android.content.ComponentName
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

class EdgeLightingService : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        super.onNotificationPosted(sbn)

        if (sbn.packageName == packageName) return
        if (!AppFilterRepository.isPackageAllowed(applicationContext, sbn.packageName)) return
        if (!passesNoiseFilters(sbn)) return

        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim() ?: ""
        val text = (extras.getCharSequence(Notification.EXTRA_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_BIG_TEXT))?.toString()?.trim() ?: ""

        // İçerik yoksa gösterecek bir şey de yok — sistemsel/boş bildirimler
        // genelde böyledir (örn. bazı arka plan senkron bildirimleri).
        if (title.isEmpty() && text.isEmpty()) return

        // Aynı bildirim kısa sürede aynı içerikle tekrar "postlandıysa"
        // (ilerleme çubuğu, medya güncellemesi vb.) tekrar tetikleme.
        val dedupeKey = "${sbn.packageName}|${sbn.id}|${sbn.tag}"
        val contentHash = (title + "\u0001" + text).hashCode()
        if (NotificationDeduper.isDuplicate(dedupeKey, contentHash)) return

        val rules = RulesRepository.getRules(applicationContext)
        val matchedRules = rules.filter { it.matches(title, text) }

        if (matchedRules.isNotEmpty()) {
            matchedRules.forEach { rule ->
                EdgeOverlayManager.enqueue(
                    applicationContext,
                    rule.color,
                    SettingsPrefs.getDurationMs(applicationContext),
                    SettingsPrefs.getThicknessDp(applicationContext),
                    rule.animationStyle
                )
            }
        } else {
            EdgeOverlayManager.enqueue(
                applicationContext,
                SettingsPrefs.getColor(applicationContext),
                SettingsPrefs.getDurationMs(applicationContext),
                SettingsPrefs.getThicknessDp(applicationContext),
                SettingsPrefs.getDefaultAnimation(applicationContext)
            )
        }
    }

    /**
     * Gerçek bir kullanıcı bildirimi olmayan durumları eler:
     * - Süregelen (ongoing) / grup özeti / yalnızca-yerel / önplan servisi bildirimleri
     * - Medya kontrolleri, servis, ilerleme kategorisi
     * - Kullanıcının SESSİZE ALDIĞI bildirim kanalları (IMPORTANCE_MIN/NONE) —
     *   bu, "sessize alınmış gruplardan gelen mesajlar bile tetikliyor" şikayetinin çözümü.
     */
    private fun passesNoiseFilters(sbn: StatusBarNotification): Boolean {
        val notification = sbn.notification

        if (sbn.isOngoing) return false
        if (notification.flags and Notification.FLAG_GROUP_SUMMARY != 0) return false
        if (notification.flags and Notification.FLAG_LOCAL_ONLY != 0) return false
        if (notification.flags and Notification.FLAG_FOREGROUND_SERVICE != 0) return false
        if (notification.flags and Notification.FLAG_NO_CLEAR != 0 && sbn.isOngoing) return false

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            when (notification.category) {
                Notification.CATEGORY_TRANSPORT,
                Notification.CATEGORY_SERVICE,
                Notification.CATEGORY_PROGRESS -> return false
            }

            val channelId = notification.channelId
            if (!channelId.isNullOrEmpty()) {
                try {
                    val channel = getNotificationChannel(sbn.packageName, sbn.user, channelId)
                    if (channel != null &&
                        (channel.importance == NotificationManager.IMPORTANCE_NONE ||
                         channel.importance == NotificationManager.IMPORTANCE_MIN)
                    ) {
                        return false
                    }
                } catch (e: Exception) {
                    // Kanal bilgisine erişilemiyorsa sessizce yok say, engelleme.
                }
            }
        }

        return true
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        Log.d("EdgeLightingService", "Listener connected")
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        Log.d("EdgeLightingService", "Listener disconnected, requesting rebind")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            requestRebind(ComponentName(this, EdgeLightingService::class.java))
        }
    }
}
