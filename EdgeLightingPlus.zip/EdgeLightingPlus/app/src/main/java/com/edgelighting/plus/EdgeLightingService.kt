package com.edgelighting.plus

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class EdgeLightingService : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        super.onNotificationPosted(sbn)

        // Ignore our own notifications and ongoing/foreground-service noise.
        if (sbn.packageName == packageName) return
        if (sbn.isOngoing) return

        val color = SettingsPrefs.getColor(applicationContext)
        val duration = SettingsPrefs.getDurationMs(applicationContext)
        val thickness = SettingsPrefs.getThicknessDp(applicationContext)

        // Every notification gets enqueued here. The FIFO queue inside
        // EdgeOverlayManager is what guarantees the 2nd, 3rd, etc.
        // notification actually plays its glow instead of being lost.
        EdgeOverlayManager.enqueue(applicationContext, color, duration, thickness)
    }
}
