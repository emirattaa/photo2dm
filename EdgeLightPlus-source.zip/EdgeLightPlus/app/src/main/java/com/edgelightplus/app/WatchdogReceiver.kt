package com.edgelightplus.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

/**
 * KeepAliveForegroundService.onDestroy()/onTaskRemoved() tarafından kısa bir
 * gecikmeyle planlanır. Servis hâlâ isteniyorsa (kullanıcı kapatmadıysa ve
 * bildirim erişimi hâlâ verilmişse) onu yeniden başlatır. Sistem/OEM bizi
 * agresif şekilde öldürse bile arka planda çalışmaya devam etmemizi sağlayan
 * son güvenlik ağı budur.
 */
class WatchdogReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val prefs = context.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(Prefs.KEY_ENABLED, true)) return

        val flat = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners")
        if (flat?.contains(context.packageName) != true) return

        KeepAliveForegroundService.start(context)
    }
}
