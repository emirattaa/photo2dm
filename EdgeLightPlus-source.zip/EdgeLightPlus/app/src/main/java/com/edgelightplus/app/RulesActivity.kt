package com.edgelightplus.app

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.RadioGroup
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class RulesActivity : AppCompatActivity() {

    private lateinit var packageInput: EditText
    private lateinit var keywordInput: EditText
    private lateinit var colorSpinner: Spinner
    private lateinit var shapeGroup: RadioGroup
    private lateinit var rulesListView: ListView

    private lateinit var rules: MutableList<NotificationRule>

    // Small curated palette so users don't need a full color picker.
    private val paletteNames = listOf(
        "Pembe (Instagram)", "Yeşil (WhatsApp)", "Mavi", "Kırmızı", "Sarı", "Mor", "Turuncu"
    )
    private val paletteColors = listOf(
        0xFFE1306C.toInt(), 0xFF25D366.toInt(), 0xFF3B82F6.toInt(),
        0xFFEA4335.toInt(), 0xFFFBBC05.toInt(), 0xFF8B5CF6.toInt(), 0xFFF97316.toInt()
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rules)
        title = getString(R.string.open_rules)

        packageInput = findViewById(R.id.inputPackage)
        keywordInput = findViewById(R.id.inputKeyword)
        colorSpinner = findViewById(R.id.spinnerColor)
        shapeGroup = findViewById(R.id.radioShape)
        rulesListView = findViewById(R.id.listRules)

        colorSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, paletteNames)

        findViewById<Button>(R.id.btnAddRule).setOnClickListener { addRuleFromForm() }

        rules = RulesManager.loadRules(this).toMutableList()
        refreshList()
    }

    private fun addRuleFromForm() {
        val pkg = packageInput.text.toString().trim()
        val keyword = keywordInput.text.toString().trim()
        if (pkg.isEmpty()) {
            packageInput.error = getString(R.string.package_required)
            return
        }
        val color = paletteColors[colorSpinner.selectedItemPosition]
        val shape = if (shapeGroup.checkedRadioButtonId == R.id.radioHeart) GlowShape.HEART else GlowShape.EDGE

        RulesManager.addRule(this, pkg, keyword, color, shape)
        rules = RulesManager.loadRules(this).toMutableList()
        refreshList()

        packageInput.text.clear()
        keywordInput.text.clear()
    }

    private fun refreshList() {
        rulesListView.adapter = RuleAdapter(rules) { rule ->
            RulesManager.deleteRule(this, rule.id)
            rules = RulesManager.loadRules(this).toMutableList()
            refreshList()
        }
    }

    private inner class RuleAdapter(
        private val items: List<NotificationRule>,
        private val onDelete: (NotificationRule) -> Unit
    ) : android.widget.BaseAdapter() {

        override fun getCount(): Int = items.size
        override fun getItem(position: Int): NotificationRule = items[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val view = convertView ?: LayoutInflater.from(this@RulesActivity)
                .inflate(R.layout.item_rule, parent, false)

            val rule = items[position]
            val label = view.findViewById<TextView>(R.id.ruleLabel)
            val deleteBtn = view.findViewById<ImageButton>(R.id.btnDeleteRule)
            val swatch = view.findViewById<View>(R.id.ruleColorSwatch)

            val shapeLabel = if (rule.shape == GlowShape.HEART) "Kalp" else "Kenar Işığı"
            val keywordPart = if (rule.keyword.isBlank()) "her bildirim" else "\"${rule.keyword}\" geçiyorsa"
            label.text = "${rule.packageName}\n$keywordPart → $shapeLabel"

            swatch.setBackgroundColor(rule.color)
            deleteBtn.setOnClickListener { onDelete(rule) }

            return view
        }
    }
}
