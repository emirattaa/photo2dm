package com.edgelightplus.app

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.FrameLayout

/**
 * WHY THIS CLASS EXISTS ("uygulama açık olmayınca / kilit ekranında çizmiyor"):
 *
 * EdgeOverlayManager normalde TYPE_APPLICATION_OVERLAY tipinde bir pencereyi
 * doğrudan Service'ten WindowManager ile ekliyor. Android 8.0 (API 26) bu
 * pencere tipini "uygulama" katmanına taşıdı ve bunu AÇIKÇA "sistem arayüzü"
 * (durum çubuğu, gezinme çubuğu VE KİLİT EKRANI) üzerine çizemeyecek şekilde
 * kısıtladı - bu bir izin meselesi değil, pencere TİPİNİN kendisiyle ilgili
 * sabit bir OS davranışı. FLAG_SHOW_WHEN_LOCKED / FLAG_TURN_SCREEN_ON gibi
 * bayrakları o pencereye ne kadar eklersek ekleyelim hiçbir fark etmiyor -
 * bir önceki denemede tam olarak bu yüzden sonuç değişmedi: bildirim geldiğinde
 * pencere gerçekten ekleniyor ve animasyon gerçekten çalışıyordu, ama telefon
 * kilitliyken o pencere tipi hiçbir zaman görünür olamıyordu.
 *
 * Üçüncü parti bir uygulamanın kilit ekranının ÜZERİNE gerçekten çizebilmesinin
 * tek yolu bir Activity penceresidir (sıradan bir "uygulama penceresi" - sistem
 * arayüzü kısıtlamasına tabi değil), showWhenLocked/turnScreenOn ile
 * işaretlenmiş olarak. Diğer edge-light uygulamalarının kilit ekranında
 * çalışabilmesinin sebebi tam olarak budur.
 *
 * Bir Service'ten Activity başlatmak normalde de kısıtlıdır (Android 10+ arka
 * plan Activity başlatma kısıtlamaları) - ama SYSTEM_ALERT_WINDOW iznini tutan
 * uygulamalar bu kısıtlamadan muaftır (bu uygulama zaten temel özelliği için bu
 * izne sahip olmak zorunda), yani kullanıcıdan ekstra hiçbir şey istemeden
 * çalışır.
 *
 * Görünmez/tıklanamaz: bu Activity kullanıcıdan hiçbir etkileşim istemiyor,
 * dokunmaları kendi altındaki (kilit ekranı dahil) pencereye geçiriyor ve
 * animasyon bitince kendini otomatik kapatıyor.
 */
class EdgeGlowActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Non-secure keyguard'ı (PIN/desen yoksa) tamamen atlat; güvenli
        // kilitte kullanıcı yine kendi ekranını görmeye devam eder, glow onun
        // üstünde belirir - içerik hassas olmadığı için (sadece renk/animasyon,
        // bildirim metni yok) bunda güvenlik sorunu yok.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val km = getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
            km?.requestDismissKeyguard(this, null)
        }

        window.addFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        )
        window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        @Suppress("DEPRECATION")
        window.setFlags(
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        )

        val color = intent.getIntExtra(EXTRA_COLOR, Color.WHITE)
        val shapeOrdinal = intent.getIntExtra(EXTRA_SHAPE, GlowShape.EDGE.ordinal)
        val shape = GlowShape.values().getOrElse(shapeOrdinal) { GlowShape.EDGE }

        val root = FrameLayout(this)
        setContentView(root)

        val glowView = EdgeGlowView(this, color, shape) {
            finish()
            overridePendingTransition(0, 0)
        }
        root.addView(glowView)
        glowView.startGlowAnimation()
    }

    companion object {
        private const val EXTRA_COLOR = "color"
        private const val EXTRA_SHAPE = "shape"

        fun start(context: Context, color: Int, shape: GlowShape) {
            val intent = Intent(context, EdgeGlowActivity::class.java).apply {
                putExtra(EXTRA_COLOR, color)
                putExtra(EXTRA_SHAPE, shape.ordinal)
                addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_NO_ANIMATION or
                        Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS or
                        Intent.FLAG_ACTIVITY_NO_HISTORY or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP
                )
            }
            try {
                context.startActivity(intent)
            } catch (e: Exception) {
                android.util.Log.w("EdgeLightPlus", "EdgeGlowActivity could not be started", e)
            }
        }
    }
}
