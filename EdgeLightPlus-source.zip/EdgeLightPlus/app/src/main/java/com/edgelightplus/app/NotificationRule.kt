package com.edgelightplus.app

import org.json.JSONObject

/**
 * A user-defined rule: when a notification from [packageName] arrives, and its
 * NAME (Notification.EXTRA_TITLE - on chat apps this is the sender's name, e.g.
 * Instagram's MessagingStyle "Person" display name) contains [nameKeyword], AND
 * its DESCRIPTION (EXTRA_TEXT / the actual message body) contains [textKeyword],
 * show [shape] in [color]. Either filter left blank matches anything for that
 * field. Both blank = matches every notification from that app.
 */
data class NotificationRule(
    val id: String,
    val packageName: String,
    val nameKeyword: String,
    val textKeyword: String,
    val color: Int,
    val shape: GlowShape
) {
    fun matches(pkg: String, name: String, description: String): Boolean {
        if (pkg != packageName) return false
        if (nameKeyword.isNotBlank() && !name.lowercase().contains(nameKeyword.trim().lowercase())) {
            return false
        }
        if (textKeyword.isNotBlank() && !description.lowercase().contains(textKeyword.trim().lowercase())) {
            return false
        }
        return true
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("packageName", packageName)
        put("nameKeyword", nameKeyword)
        put("textKeyword", textKeyword)
        put("color", color)
        put("shape", shape.name)
    }

    companion object {
        fun fromJson(o: JSONObject): NotificationRule {
            return NotificationRule(
                id = o.getString("id"),
                packageName = o.getString("packageName"),
                // "keyword" kept for back-compat with rules saved by the previous app version.
                nameKeyword = o.optString("nameKeyword", o.optString("keyword", "")),
                textKeyword = o.optString("textKeyword", ""),
                color = o.getInt("color"),
                shape = try {
                    GlowShape.valueOf(o.optString("shape", GlowShape.EDGE.name))
                } catch (_: Exception) {
                    GlowShape.EDGE
                }
            )
        }
    }
}

enum class GlowShape {
    EDGE,
    HEART
}
