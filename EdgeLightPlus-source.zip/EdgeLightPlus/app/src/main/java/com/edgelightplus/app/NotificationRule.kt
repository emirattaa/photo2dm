package com.edgelightplus.app

import org.json.JSONObject

/**
 * A user-defined rule: when a notification from [packageName] arrives whose title
 * or text contains [keyword] (case-insensitive; blank = match any), show [shape]
 * in [color] instead of the default edge glow.
 */
data class NotificationRule(
    val id: String,
    val packageName: String,
    val keyword: String,
    val color: Int,
    val shape: GlowShape
) {
    fun matches(pkg: String, title: String, text: String): Boolean {
        if (pkg != packageName) return false
        if (keyword.isBlank()) return true
        val needle = keyword.trim().lowercase()
        return title.lowercase().contains(needle) || text.lowercase().contains(needle)
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("packageName", packageName)
        put("keyword", keyword)
        put("color", color)
        put("shape", shape.name)
    }

    companion object {
        fun fromJson(o: JSONObject): NotificationRule {
            return NotificationRule(
                id = o.getString("id"),
                packageName = o.getString("packageName"),
                keyword = o.optString("keyword", ""),
                color = o.getInt("color"),
                shape = try {
                    GlowShape.valueOf(o.optString("shape", GlowShape.EDGE.name))
                } catch (_: Exception) {
                    GlowShape.EDGE
                }
            )
        }
    }
}

enum class GlowShape {
    EDGE,
    HEART
}
