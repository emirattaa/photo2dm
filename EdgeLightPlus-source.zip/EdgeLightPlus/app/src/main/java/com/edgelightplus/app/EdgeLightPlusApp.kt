package com.edgelightplus.app

import android.app.Application
import android.content.ComponentName
import android.os.Build
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.util.Log

/**
 * WHY THIS EXISTS ("uygulama açık olmayınca ekrana gelmiyor" düzeltmesi):
 *
 * Şimdiye kadar KeepAliveForegroundService sadece belirli tetikleyici noktalardan
 * (MainActivity.onCreate/onResume, BootReceiver, WatchdogReceiver,
 * EdgeNotificationListenerService.onListenerConnected) başlatılıyordu. Sistem
 * uygulamayı MainActivity hiç açılmadan, sadece bağlı NotificationListenerService
 * bağlantısını sürdürmek için arka planda yeniden başlattığında, süreç ile
 * onListenerConnected() çağrısı arasında küçük bir boşluk oluşabiliyor - bazı
 * OEM ROM'ları süreci bu boşlukta tekrar öldürebiliyor, servis hiç ayağa
 * kalkmadan.
 *
 * Application.onCreate(), sürecimiz her var olduğunda (hangi sebeple olursa
 * olsun) çalışan EN ERKEN geri çağrımdır - herhangi bir Activity/Service/
 * Receiver'dan önce gelir. Bu yüzden keep-alive servisini yeniden iddia etmek
 * ve dinleyiciyi yeniden bağlamaya zorlamak için en güvenilir yer burasıdır.
 *
 * NOT: startForegroundService() çağrısı, uygulama arka plandayken (Android 12+)
 * bazı istisnalar dışında ForegroundServiceStartNotAllowedException fırlatabilir.
 * Uygulama zaten SYSTEM_ALERT_WINDOW iznini (çekirdek özelliğimiz için zorunlu)
 * ve genelde pil optimizasyonu istisnasını tuttuğu için bu istisnalardan en az
 * biri normal şartlarda devreye girer - ama garanti olsun diye
 * KeepAliveForegroundService.start() içinde de ayrıca yakalanıyor, tek bir
 * başarısız deneme yüzünden tüm kurtarma zincirinin kesilmemesi için.
 */
class EdgeLightPlusApp : Application() {

    override fun onCreate() {
        super.onCreate()

        val prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
        if (!prefs.getBoolean(Prefs.KEY_ENABLED, true)) return
        if (!isNotificationListenerGranted()) return

        KeepAliveForegroundService.start(this)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                NotificationListenerService.requestRebind(
                    ComponentName(this, EdgeNotificationListenerService::class.java)
                )
            } catch (e: Exception) {
                // Bazı OEM ROM'larında bu çağrı kısıtlanmış olabilir; dinleyici
                // zaten kendi zamanlamasında ya da bir sonraki tetikleyici
                // noktada (onListenerConnected, boot, watchdog) yeniden
                // bağlanmayı dener.
                Log.w(TAG, "requestRebind failed from Application.onCreate", e)
            }
        }
    }

    private fun isNotificationListenerGranted(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return flat?.contains(packageName) == true
    }

    companion object {
        private const val TAG = "EdgeLightPlus"
    }
}
