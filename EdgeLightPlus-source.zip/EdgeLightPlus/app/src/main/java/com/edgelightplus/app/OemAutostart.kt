package com.edgelightplus.app

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings

/**
 * Standart Android pil optimizasyonu istisnası (REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
 * birçok Çin OEM'inde (Xiaomi/MIUI, Oppo/ColorOS, Vivo/FuntouchOS, Huawei/EMUI,
 * Honor, Meizu, Asus, Samsung'un kendi "Uyku moduna al" listesi vb.) YETERLİ
 * DEĞİLDİR. Bu üreticilerin, standart Android API'lerinin dışında kendi
 * "Otomatik Başlatma" / "Korumalı Uygulamalar" ayar ekranları vardır ve
 * kullanıcı orada da uygulamayı elle işaretlemedikçe arka plan servisini/
 * bildirim dinleyicisini kendi RAM temizleyicileriyle öldürmeye devam ederler.
 *
 * Kod tarafında bunu tamamen çözmek mümkün değil - kullanıcının bu ekranda
 * elle bir anahtarı açması gerekiyor. Yapabileceğimiz en iyi şey, cihazın
 * üreticisini tespit edip doğru ekranı doğrudan açmak (mümkünse), olmuyorsa
 * uygulamanın "Uygulama Bilgileri" ekranına düşmek.
 */
object OemAutostart {

    /** Bilinen kısıtlayıcı bir OEM'de miyiz? MainActivity bu ekranı sadece o zaman öne çıkarır. */
    fun isKnownRestrictiveOem(): Boolean {
        val manufacturer = Build.MANUFACTURER.lowercase()
        return RESTRICTIVE_MANUFACTURERS.any { manufacturer.contains(it) }
    }

    fun manufacturerDisplayName(): String = Build.MANUFACTURER

    /** Sırayla dener; ilk açılabilen ekranda durur, hiçbiri açılmazsa uygulama detay ekranına düşer. */
    fun openAutostartSettings(context: Context) {
        val manufacturer = Build.MANUFACTURER.lowercase()
        val candidates = when {
            manufacturer.contains("xiaomi") || manufacturer.contains("redmi") || manufacturer.contains("poco") -> xiaomiIntents(context)
            manufacturer.contains("oppo") -> oppoIntents()
            manufacturer.contains("vivo") -> vivoIntents()
            manufacturer.contains("huawei") || manufacturer.contains("honor") -> huaweiIntents()
            manufacturer.contains("samsung") -> samsungIntents()
            manufacturer.contains("asus") -> asusIntents()
            manufacturer.contains("letv") || manufacturer.contains("leeco") -> letvIntents()
            manufacturer.contains("meizu") -> meizuIntents(context)
            else -> emptyList()
        }

        for (intent in candidates) {
            if (tryStart(context, intent)) return
        }

        // Son çare: hiçbir OEM-özel ekran açılamadıysa, en azından uygulama
        // detay ekranını aç ki kullanıcı "Pil" bölümüne kendi gidebilsin.
        tryStart(
            context,
            Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:${context.packageName}")
            )
        )
    }

    private fun tryStart(context: Context, intent: Intent): Boolean {
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            true
        } catch (_: ActivityNotFoundException) {
            false
        } catch (_: Exception) {
            false
        }
    }

    private fun xiaomiIntents(context: Context) = listOf(
        Intent().setClassName(
            "com.miui.securitycenter",
            "com.miui.permcenter.autostart.AutoStartManagementActivity"
        ),
        Intent("miui.intent.action.APP_PERM_EDITOR").apply {
            setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.PermissionsEditorActivity")
            putExtra("extra_pkgname", context.packageName)
        },
        Intent().setClassName(
            "com.miui.securitycenter",
            "com.miui.securitycenter.Main"
        )
    )

    private fun oppoIntents() = listOf(
        Intent().setClassName(
            "com.coloros.safecenter",
            "com.coloros.safecenter.permission.startup.StartupAppListActivity"
        ),
        Intent().setClassName(
            "com.coloros.safecenter",
            "com.coloros.safecenter.startupapp.StartupAppListActivity"
        ),
        Intent().setClassName(
            "com.oppo.safe",
            "com.oppo.safe.permission.startup.StartupAppListActivity"
        )
    )

    private fun vivoIntents() = listOf(
        Intent().setClassName(
            "com.vivo.permissionmanager",
            "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"
        ),
        Intent().setClassName(
            "com.iqoo.secure",
            "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity"
        )
    )

    private fun huaweiIntents() = listOf(
        Intent().setClassName(
            "com.huawei.systemmanager",
            "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"
        ),
        Intent().setClassName(
            "com.huawei.systemmanager",
            "com.huawei.systemmanager.optimize.process.ProtectActivity"
        )
    )

    private fun samsungIntents() = listOf(
        // Samsung "Uyku moduna alınmayacak uygulamalar" ekranı sabit bir aktivite
        // adıyla gelmiyor; en güvenilir yol pil kullanım ayarları ekranıdır.
        Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
    )

    private fun asusIntents() = listOf(
        Intent().setClassName(
            "com.asus.mobilemanager",
            "com.asus.mobilemanager.autostart.AutoStartActivity"
        )
    )

    private fun letvIntents() = listOf(
        Intent().setClassName(
            "com.letv.android.letvsafe",
            "com.letv.android.letvsafe.AutobootManageActivity"
        )
    )

    private fun meizuIntents(context: Context) = listOf(
        Intent("com.meizu.safe.security.SHOW_APPSEC").apply {
            addCategory(Intent.CATEGORY_DEFAULT)
            putExtra("packageName", context.packageName)
        }
    )

    private val RESTRICTIVE_MANUFACTURERS = listOf(
        "xiaomi", "redmi", "poco", "oppo", "vivo", "iqoo", "huawei", "honor",
        "asus", "letv", "leeco", "meizu", "samsung"
    )
}
