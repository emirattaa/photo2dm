package com.edgelightplus.app

import android.content.Context
import org.json.JSONArray
import java.util.UUID

object RulesManager {

    private const val KEY_RULES = "rules_json"

    fun loadRules(context: Context): List<NotificationRule> {
        val prefs = context.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_RULES, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { NotificationRule.fromJson(arr.getJSONObject(it)) }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveRules(context: Context, rules: List<NotificationRule>) {
        val arr = JSONArray()
        rules.forEach { arr.put(it.toJson()) }
        context.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_RULES, arr.toString())
            .apply()
    }

    fun addRule(context: Context, packageName: String, keyword: String, color: Int, shape: GlowShape) {
        val rules = loadRules(context).toMutableList()
        rules.add(
            NotificationRule(
                id = UUID.randomUUID().toString(),
                packageName = packageName,
                keyword = keyword,
                color = color,
                shape = shape
            )
        )
        saveRules(context, rules)
    }

    fun deleteRule(context: Context, id: String) {
        val rules = loadRules(context).filterNot { it.id == id }
        saveRules(context, rules)
    }

    /** Returns the first matching rule, or null if none matches (caller should fall back to defaults). */
    fun findMatch(context: Context, pkg: String, title: String, text: String): NotificationRule? {
        return loadRules(context).firstOrNull { it.matches(pkg, title, text) }
    }
}
