package com.edgelightplus.app

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager

/**
 * Adds a full-screen, touch-through overlay window showing the animated edge glow,
 * then removes it automatically once the animation finishes.
 */
object EdgeOverlayManager {

    private var currentView: EdgeGlowView? = null

    fun canDrawOverlays(context: Context): Boolean {
        return Settings.canDrawOverlays(context)
    }

    fun showGlow(context: Context, color: Int) {
        if (!canDrawOverlays(context)) return

        val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

        // If a glow is already showing, remove it first so the new one starts clean.
        removeCurrent(windowManager)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START

        val glowView = EdgeGlowView(context, color) {
            // onAnimationEnd callback - remove ourselves from the window.
            removeCurrent(windowManager)
        }

        try {
            windowManager.addView(glowView, params)
            currentView = glowView
            glowView.startGlowAnimation()
        } catch (_: Exception) {
            // Fails silently if permission was revoked mid-flight etc.
        }
    }

    private fun removeCurrent(windowManager: WindowManager) {
        currentView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
                // View might already be detached.
            }
        }
        currentView = null
    }
}
