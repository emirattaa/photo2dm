package com.edgelightplus.app

import android.app.KeyguardManager
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager

/**
 * Adds a full-screen, touch-through overlay window showing the animated edge glow,
 * then removes it automatically once the animation finishes.
 *
 * İki farklı çizim yolu var, telefonun durumuna göre seçiliyor:
 * - Ekran açık ve kilit yoksa (kullanıcı telefonu kullanırken bildirim geldi):
 *   TYPE_APPLICATION_OVERLAY penceresi yeterli ve daha hafif/anlık - bkz.
 *   showAsOverlay().
 * - Ekran kapalıyken veya kilit ekranındayken: TYPE_APPLICATION_OVERLAY zaten
 *   görünemez (bkz. EdgeGlowActivity içindeki açıklama), o yüzden
 *   EdgeGlowActivity'yi başlatıyoruz - bu senaryonun TEK çalışan yolu bu.
 */
object EdgeOverlayManager {

    private var currentView: EdgeGlowView? = null

    fun canDrawOverlays(context: Context): Boolean {
        return Settings.canDrawOverlays(context)
    }

    fun showGlow(context: Context, color: Int, shape: GlowShape = GlowShape.EDGE) {
        if (!canDrawOverlays(context)) return

        if (isLockedOrScreenOff(context)) {
            EdgeGlowActivity.start(context, color, shape)
        } else {
            showAsOverlay(context, color, shape)
        }
    }

    private fun isLockedOrScreenOff(context: Context): Boolean {
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val screenOff = powerManager?.isInteractive?.not() ?: false
        val keyguardManager = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        val locked = keyguardManager?.isKeyguardLocked ?: false
        return screenOff || locked
    }

    private fun showAsOverlay(context: Context, color: Int, shape: GlowShape) {
        val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

        // If a glow is already showing, remove it first so the new one starts clean.
        removeCurrent(windowManager)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START

        val glowView = EdgeGlowView(context, color, shape) {
            // onAnimationEnd callback - remove ourselves from the window.
            removeCurrent(windowManager)
        }

        try {
            windowManager.addView(glowView, params)
            currentView = glowView
            glowView.startGlowAnimation()
        } catch (e: Exception) {
            // Ekran açıkken bu neredeyse hiç başarısız olmaz; olursa en azından
            // sessizce yutuyoruz.
            android.util.Log.w("EdgeLightPlus", "Overlay could not be added", e)
        }
    }

    private fun removeCurrent(windowManager: WindowManager) {
        currentView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
                // View might already be detached.
            }
        }
        currentView = null
    }
}
