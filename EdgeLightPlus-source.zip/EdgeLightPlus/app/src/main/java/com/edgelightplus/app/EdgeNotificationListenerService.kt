package com.edgelightplus.app

import android.app.Notification
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Core listener.
 *
 * WHY INSTAGRAM (and many other chat apps) BREAK NORMAL EDGE-LIGHTING APPS:
 * Instagram posts several notifications under the same "group key" and, after the
 * first one, it frequently just UPDATES the group summary notification instead of
 * posting a brand new one. Many edge-lighting apps only look at brand-new postings,
 * or they read Notification.extras.EXTRA_TEXT which is empty/generic ("3 new
 * messages") on a group summary. So the second, third, fourth message never
 * triggers anything, or triggers with no usable text/color.
 *
 * FIX USED HERE:
 * 1. We don't ignore FLAG_GROUP_SUMMARY notifications - we still inspect them.
 * 2. NAME vs DESCRIPTION extraction, closest to how Android's own Notification API
 *    (and Instagram specifically) structure a message notification:
 *    - Chat apps built with NotificationCompat.MessagingStyle (Instagram DMs,
 *      WhatsApp, Messenger, Telegram) attach a MessagingStyle object to the
 *      notification. Android exposes it via
 *      Notification.MessagingStyle.extractMessagingStyleFromNotification(notification).
 *      Its last Message has a Person (the sender's NAME) and a text body (the
 *      DESCRIPTION) - this is the single most reliable source, and it is what we
 *      try first.
 *    - If that's absent (older apps, or non-MessagingStyle notifications like
 *      likes/comments), we fall back to EXTRA_TITLE as the name and, for the
 *      description, EXTRA_TEXT_LINES (the list Instagram uses inside a grouped
 *      "3 new notifications" summary) -> EXTRA_BIG_TEXT -> EXTRA_TEXT, in that order.
 * 3. We keep a per-conversation (per sbn.groupKey/key) signature of "last content
 *    we already animated for". Every time onNotificationPosted fires (new post OR
 *    update to an existing one), we compute a fresh signature and compare it. If it
 *    changed, we trigger the glow - this is what makes stacked/updated notifications
 *    from Instagram work at all.
 * 4. ONLY notifications that match a rule the user explicitly created in "Özel
 *    Kurallar" trigger anything (unless the user turns that requirement off in
 *    settings) - nothing fires for apps/messages the user hasn't picked.
 */
class EdgeNotificationListenerService : NotificationListenerService() {

    private val handler = Handler(Looper.getMainLooper())
    private val lastSignaturePerKey = HashMap<String, String>()

    private lateinit var prefs: SharedPreferences

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        super.onNotificationPosted(sbn)

        if (!prefs.getBoolean(Prefs.KEY_ENABLED, true)) return

        // Ignore our own app's notifications if any.
        if (sbn.packageName == packageName) return

        val notification = sbn.notification ?: return
        val extras = notification.extras ?: return

        val extracted = extractNameAndDescription(notification, extras)
        val name = extracted.first
        val description = extracted.second

        if (name.isBlank() && description.isBlank()) {
            // Nothing usable to show, skip (e.g. silent/ongoing system notifications).
            return
        }

        // Build a signature that changes whenever there's genuinely new content,
        // including when Android just updates the same notification ID/group.
        val signature = buildString {
            append(sbn.packageName).append('|')
            append(name).append('|')
            append(description).append('|')
            append(notification.`when`)
        }

        val conversationKey = sbn.groupKey ?: sbn.key
        val previous = lastSignaturePerKey[conversationKey]
        if (previous == signature) {
            // Exact same content we already animated for this conversation - skip.
            return
        }
        lastSignaturePerKey[conversationKey] = signature

        // Custom user rules (per app + name filter + description filter) decide
        // what shows. e.g. "Instagram + isim 'Ayşe' geçiyorsa kalp göster".
        val rule = RulesManager.findMatch(applicationContext, sbn.packageName, name, description)

        val onlyMatched = prefs.getBoolean(Prefs.KEY_ONLY_MATCHED_RULES, true)
        if (rule == null && onlyMatched) {
            // User asked to only react to notifications they've explicitly picked.
            return
        }

        val color = rule?.color ?: resolveColor(sbn.packageName, notification)
        val shape = rule?.shape ?: GlowShape.EDGE

        handler.post {
            EdgeOverlayManager.showGlow(applicationContext, color, shape)
        }
    }

    /**
     * Returns (name, description). Prefers Android's structured MessagingStyle API
     * (used by Instagram DMs and most chat apps) and falls back to the raw extras.
     */
    private fun extractNameAndDescription(notification: Notification, extras: android.os.Bundle): Pair<String, String> {
        try {
            val messagingStyle =
                androidx.core.app.NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(notification)
            val lastMessage = messagingStyle?.messages?.lastOrNull()
            if (lastMessage != null) {
                @Suppress("DEPRECATION")
                val senderName = lastMessage.person?.name?.toString()
                    ?: lastMessage.sender?.toString()
                    ?: messagingStyle.userDisplayName?.toString().orEmpty()
                val text = lastMessage.text?.toString().orEmpty()
                if (senderName.isNotBlank() || text.isNotBlank()) {
                    return senderName to text
                }
            }
        } catch (_: Exception) {
            // Not a MessagingStyle notification, or API not available - fall through.
        }

        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()

        // EXTRA_TEXT_LINES holds each stacked line for grouped/InboxStyle notifications
        // (this is what Instagram falls back to inside a "X new notifications" summary).
        val lines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
        val latestLine = lines?.lastOrNull()?.toString()

        val plainText = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()

        val bestText = when {
            !latestLine.isNullOrBlank() -> latestLine
            bigText.isNotBlank() -> bigText
            plainText.isNotBlank() -> plainText
            else -> ""
        }

        return title to bestText
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        // The listener is actively bound - make sure our keep-alive foreground
        // service is running too, so the process survives Samsung/OEM memory sweeps.
        KeepAliveForegroundService.start(applicationContext)
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        // Ask the system to rebind us as soon as possible instead of waiting for
        // the next notification event. Helps recover faster after the OS/Samsung
        // battery manager temporarily tears the connection down.
        requestRebind(android.content.ComponentName(this, EdgeNotificationListenerService::class.java))
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        super.onNotificationRemoved(sbn)
        val conversationKey = sbn.groupKey ?: sbn.key
        lastSignaturePerKey.remove(conversationKey)
    }

    /**
     * Picks an accent color: prefers the notification's own accent color if the app
     * set one, otherwise falls back to a curated per-app color, otherwise a default.
     * Only used when no custom rule matched and "sadece kurallar" is turned off.
     */
    private fun resolveColor(packageName: String, notification: Notification): Int {
        val notifColor = notification.color
        if (notifColor != 0 && notifColor != Color.WHITE && notifColor != Color.BLACK) {
            return notifColor
        }
        return KNOWN_APP_COLORS[packageName] ?: DEFAULT_COLOR
    }

    companion object {
        private const val DEFAULT_COLOR = 0xFF3B82F6.toInt() // blue

        private val KNOWN_APP_COLORS = mapOf(
            "com.instagram.android" to 0xFFE1306C.toInt(),   // Instagram pink/magenta
            "com.whatsapp" to 0xFF25D366.toInt(),             // WhatsApp green
            "com.google.android.gm" to 0xFFEA4335.toInt(),    // Gmail red
            "com.twitter.android" to 0xFF1DA1F2.toInt(),      // Twitter/X blue
            "com.facebook.orca" to 0xFF0084FF.toInt(),        // Messenger blue
            "org.telegram.messenger" to 0xFF2AABEE.toInt()    // Telegram blue
        )
    }
}
