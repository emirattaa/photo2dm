package com.edgelightplus.app

import android.app.Notification
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Core listener.
 *
 * WHY INSTAGRAM (and many other chat apps) BREAK NORMAL EDGE-LIGHTING APPS:
 * Instagram posts several notifications under the same "group key" and, after the
 * first one, it frequently just UPDATES the group summary notification instead of
 * posting a brand new one. Many edge-lighting apps only look at brand-new postings,
 * or they read Notification.extras.EXTRA_TEXT which is empty/generic ("3 new
 * messages") on a group summary. So the second, third, fourth message never
 * triggers anything, or triggers with no usable text/color.
 *
 * FIX USED HERE:
 * 1. We don't ignore FLAG_GROUP_SUMMARY notifications - we still inspect them.
 * 2. We read Notification.EXTRA_TEXT_LINES (InboxStyle lines) which Instagram/Gmail/
 *    WhatsApp etc. populate with one line per stacked message inside the summary.
 *    We take the LAST line as the newest message.
 * 3. We keep a per-conversation (per sbn.key) signature of "last content we already
 *    animated for". Every time onNotificationPosted fires (new post OR update to an
 *    existing one), we compute a fresh signature and compare it. If it changed, we
 *    trigger the glow - this is what makes stacked/updated notifications work.
 */
class EdgeNotificationListenerService : NotificationListenerService() {

    private val handler = Handler(Looper.getMainLooper())
    private val lastSignaturePerKey = HashMap<String, String>()

    private lateinit var prefs: SharedPreferences

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        super.onNotificationPosted(sbn)

        if (!prefs.getBoolean(Prefs.KEY_ENABLED, true)) return

        // Ignore our own app's notifications if any.
        if (sbn.packageName == packageName) return

        val notification = sbn.notification ?: return
        val extras = notification.extras ?: return

        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()

        // EXTRA_TEXT_LINES holds each stacked line for grouped/InboxStyle notifications
        // (this is what Instagram uses for "X new messages" summaries).
        val lines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
        val latestLine = lines?.lastOrNull()?.toString()

        val plainText = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()

        val bestText = when {
            !latestLine.isNullOrBlank() -> latestLine
            bigText.isNotBlank() -> bigText
            plainText.isNotBlank() -> plainText
            else -> ""
        }

        val subText = extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString().orEmpty()

        // Build a signature that changes whenever there's genuinely new content,
        // including when Android just updates the same notification ID/group.
        val signature = buildString {
            append(sbn.packageName).append('|')
            append(title).append('|')
            append(bestText).append('|')
            append(subText).append('|')
            append(lines?.size ?: 0).append('|')
            append(notification.`when`)
        }

        if (bestText.isBlank() && title.isBlank()) {
            // Nothing usable to show, skip (e.g. silent/ongoing system notifications).
            return
        }

        val conversationKey = sbn.groupKey ?: sbn.key
        val previous = lastSignaturePerKey[conversationKey]
        if (previous == signature) {
            // Exact same content we already animated for this conversation - skip.
            return
        }
        lastSignaturePerKey[conversationKey] = signature

        // Custom user rules (per app + keyword in title/text) take priority over
        // the default per-app color, e.g. "Instagram + isim 'Ayşe' geçiyorsa kalp göster".
        val rule = RulesManager.findMatch(applicationContext, sbn.packageName, title, bestText)
        val color = rule?.color ?: resolveColor(sbn.packageName, notification)
        val shape = rule?.shape ?: GlowShape.EDGE

        handler.post {
            EdgeOverlayManager.showGlow(applicationContext, color, shape)
        }
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        // Ask the system to rebind us as soon as possible instead of waiting for
        // the next notification event. Helps recover faster after the OS/Samsung
        // battery manager temporarily tears the connection down.
        requestRebind(android.content.ComponentName(this, EdgeNotificationListenerService::class.java))
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        super.onNotificationRemoved(sbn)
        val conversationKey = sbn.groupKey ?: sbn.key
        lastSignaturePerKey.remove(conversationKey)
    }

    /**
     * Picks an accent color: prefers the notification's own accent color if the app
     * set one, otherwise falls back to a curated per-app color, otherwise a default.
     */
    private fun resolveColor(packageName: String, notification: Notification): Int {
        val notifColor = notification.color
        if (notifColor != 0 && notifColor != Color.WHITE && notifColor != Color.BLACK) {
            return notifColor
        }
        return KNOWN_APP_COLORS[packageName] ?: DEFAULT_COLOR
    }

    companion object {
        private const val DEFAULT_COLOR = 0xFF3B82F6.toInt() // blue

        private val KNOWN_APP_COLORS = mapOf(
            "com.instagram.android" to 0xFFE1306C.toInt(),   // Instagram pink/magenta
            "com.whatsapp" to 0xFF25D366.toInt(),             // WhatsApp green
            "com.google.android.gm" to 0xFFEA4335.toInt(),    // Gmail red
            "com.twitter.android" to 0xFF1DA1F2.toInt(),      // Twitter/X blue
            "com.facebook.orca" to 0xFF0084FF.toInt(),        // Messenger blue
            "org.telegram.messenger" to 0xFF2AABEE.toInt()    // Telegram blue
        )
    }
}
