package com.edgelightplus.app

import android.app.Notification
import android.content.SharedPreferences
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Core listener.
 *
 * WHY INSTAGRAM (and many other chat apps) BREAK NORMAL EDGE-LIGHTING APPS:
 * Instagram posts several notifications under the same "group key" and, after the
 * first one, it frequently just UPDATES the group summary notification instead of
 * posting a brand new one. Many edge-lighting apps only look at brand-new postings,
 * or they read Notification.extras.EXTRA_TEXT which is empty/generic ("3 new
 * messages") on a group summary. So the second, third, fourth message never
 * triggers anything, or triggers with no usable text/color.
 *
 * FIX USED HERE:
 * 1. We don't ignore FLAG_GROUP_SUMMARY notifications - we still inspect them.
 * 2. NAME vs DESCRIPTION extraction, closest to how Android's own Notification API
 *    (and Instagram specifically) structure a message notification:
 *    - Chat apps built with NotificationCompat.MessagingStyle (Instagram DMs,
 *      WhatsApp, Messenger, Telegram) attach a MessagingStyle object to the
 *      notification. Android exposes it via
 *      Notification.MessagingStyle.extractMessagingStyleFromNotification(notification).
 *      Its last Message has a Person (the sender's NAME) and a text body (the
 *      DESCRIPTION) - this is the single most reliable source, and it is what we
 *      try first.
 *    - If that's absent (older apps, or non-MessagingStyle notifications like
 *      likes/comments), we fall back to EXTRA_TITLE as the name and, for the
 *      description, EXTRA_TEXT_LINES (the list Instagram uses inside a grouped
 *      "3 new notifications" summary) -> EXTRA_BIG_TEXT -> EXTRA_TEXT, in that order.
 * 3. We keep a per-conversation (per sbn.groupKey/key) signature of "last content
 *    we already animated for". Every time onNotificationPosted fires (new post OR
 *    update to an existing one), we compute a fresh signature and compare it. If it
 *    changed, we trigger the glow - this is what makes stacked/updated notifications
 *    from Instagram work at all.
 * 4. ONLY notifications that match a rule the user explicitly created in "Özel
 *    Kurallar" trigger anything - nothing fires for apps/messages the user
 *    hasn't picked, no exceptions and no toggle to turn that off.
 * 5. ONLY genuine message-type notifications are considered at all - ongoing
 *    notifications (music players, downloads, calls in progress...) and
 *    "ambient" categories (like/comment/follow, promos, system, status,
 *    recommendations) are skipped before rule-matching ever runs. Without this,
 *    a rule added for e.g. Instagram with no name/text filter (matches every
 *    notification from that app) also lit up for likes, comments, "someone you
 *    follow posted", login alerts etc. - not just for actual DMs. This is very
 *    likely the "bildirim gelince VE bir şey daha olunca" (fires on notification
 *    AND some other invisible condition) confusion: the "something else" was
 *    simply "...and it happened to be a non-message Instagram notification too".
 * 6. A short (1.2s) per-conversation cooldown blocks near-simultaneous duplicate
 *    posts (the individual notification + the group summary Android posts right
 *    after it) from firing the glow twice for what is really one message.
 */
class EdgeNotificationListenerService : NotificationListenerService() {

    private val lastSignaturePerKey = HashMap<String, String>()
    private val lastTriggerAtPerKey = HashMap<String, Long>()

    private lateinit var prefs: SharedPreferences

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        super.onNotificationPosted(sbn)

        if (!prefs.getBoolean(Prefs.KEY_ENABLED, true)) return

        // Ignore our own app's notifications if any.
        if (sbn.packageName == packageName) return

        val notification = sbn.notification ?: return

        // Skip anything that isn't a genuine, dismissible message notification.
        // A music player's "now playing" card, a download progress bar, an
        // active call, or Instagram's "beğenildi/takip etti/önerilen" style
        // notifications should never be able to trigger the glow, even if the
        // user's rule for that app has no name/text filter set.
        if (!looksLikeRealMessage(notification)) return

        val extras = notification.extras ?: return

        val extracted = extractNameAndDescription(notification, extras)
        val name = extracted.first
        val description = extracted.second

        if (name.isBlank() && description.isBlank()) {
            // Nothing usable to show, skip (e.g. silent/ongoing system notifications).
            return
        }

        val conversationKey = sbn.groupKey ?: sbn.key

        // Cooldown: Android frequently posts the individual message AND updates
        // the group summary within milliseconds of each other. Without this, both
        // postings could pass the content-signature check below (if their
        // extracted text happens to differ slightly) and fire the glow twice for
        // one real message.
        val now = System.currentTimeMillis()
        val lastTrigger = lastTriggerAtPerKey[conversationKey]
        if (lastTrigger != null && now - lastTrigger < DUPLICATE_COOLDOWN_MS) {
            return
        }

        // Build a signature that changes whenever there's genuinely new content,
        // including when Android just updates the same notification ID/group.
        val signature = buildString {
            append(sbn.packageName).append('|')
            append(name).append('|')
            append(description).append('|')
            append(notification.`when`)
        }

        val previous = lastSignaturePerKey[conversationKey]
        if (previous == signature) {
            // Exact same content we already animated for this conversation - skip.
            return
        }
        lastSignaturePerKey[conversationKey] = signature

        // Custom user rules (per app + name filter + description filter) decide
        // what shows. e.g. "Instagram + isim 'Ayşe' geçiyorsa kalp göster".
        //
        // KESİN KURAL: Kullanıcı "Özel Kurallar" ekranında bir kural eklemediği
        // sürece HİÇBİR bildirim ışığı tetiklemez. Daha önce burada "kural yoksa
        // bilinen uygulamanın rengiyle yine de göster" diye bir yedek davranış
        // vardı - kullanıcının "seçmediğim bildirimler için de yanıyor, neden
        // olduğunu anlamadım" şikayetinin kaynağı buydu. O yedek davranış ve
        // buna bağlı aç/kapa anahtarı tamamen kaldırıldı; artık davranış açık,
        // tek ve öngörülebilir: sadece seçtiğiniz bildirimler.
        val rule = RulesManager.findMatch(applicationContext, sbn.packageName, name, description)
        if (rule == null) return

        lastTriggerAtPerKey[conversationKey] = now

        val color = rule.color
        val shape = rule.shape

        // Doğrudan çağırıyoruz (handler.post ile ertelemiyoruz): onNotificationPosted
        // zaten ana thread'de çalışıyor, ekstra bir Handler.post() adımı burada hiçbir
        // şey kazandırmıyor ama küçük bir risk ekliyor - uygulama arka planda
        // "dondurulmuş" durumdaysa (Android'in cached app freezer'ı), kuyruğa
        // eklenen Runnable hiç çalışmadan sıkışıp kalabilir. Doğrudan çağrı, aynı
        // bağlayıcı (binder) çağrısı içinde penceyi hemen ekler.
        EdgeOverlayManager.showGlow(applicationContext, color, shape)
    }

    /**
     * Ongoing notifications (foreground services: music, calls, downloads, nav)
     * and Android's "ambient" categories (promo/recommendation/social reactions/
     * system/status/progress/transport) are never real one-off messages - filter
     * them out before a rule even gets a chance to match.
     */
    private fun looksLikeRealMessage(notification: Notification): Boolean {
        if (notification.flags and Notification.FLAG_ONGOING_EVENT != 0) return false
        val category = notification.category ?: return true
        val ambientCategories = setOf(
            Notification.CATEGORY_PROGRESS,
            Notification.CATEGORY_TRANSPORT,
            Notification.CATEGORY_SERVICE,
            Notification.CATEGORY_SYSTEM,
            Notification.CATEGORY_STATUS,
            Notification.CATEGORY_PROMO,
            Notification.CATEGORY_RECOMMENDATION
        )
        return category !in ambientCategories
    }

    /**
     * Returns (name, description). Prefers Android's structured MessagingStyle API
     * (used by Instagram DMs and most chat apps) and falls back to the raw extras.
     */
    private fun extractNameAndDescription(notification: Notification, extras: android.os.Bundle): Pair<String, String> {
        try {
            val messagingStyle =
                androidx.core.app.NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(notification)
            val lastMessage = messagingStyle?.messages?.lastOrNull()
            if (lastMessage != null) {
                @Suppress("DEPRECATION")
                val senderName = lastMessage.person?.name?.toString()
                    ?: lastMessage.sender?.toString()
                    ?: messagingStyle.userDisplayName?.toString().orEmpty()
                val text = lastMessage.text?.toString().orEmpty()
                if (senderName.isNotBlank() || text.isNotBlank()) {
                    return senderName to text
                }
            }
        } catch (_: Exception) {
            // Not a MessagingStyle notification, or API not available - fall through.
        }

        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()

        // EXTRA_TEXT_LINES holds each stacked line for grouped/InboxStyle notifications
        // (this is what Instagram falls back to inside a "X new notifications" summary).
        val lines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
        val latestLine = lines?.lastOrNull()?.toString()

        val plainText = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()

        val bestText = when {
            !latestLine.isNullOrBlank() -> latestLine
            bigText.isNotBlank() -> bigText
            plainText.isNotBlank() -> plainText
            else -> ""
        }

        return title to bestText
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        // The listener is actively bound - make sure our keep-alive foreground
        // service is running too, so the process survives Samsung/OEM memory sweeps.
        KeepAliveForegroundService.start(applicationContext)
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        // Ask the system to rebind us as soon as possible instead of waiting for
        // the next notification event. Helps recover faster after the OS/Samsung
        // battery manager temporarily tears the connection down.
        try {
            requestRebind(android.content.ComponentName(this, EdgeNotificationListenerService::class.java))
        } catch (_: Exception) {
            // Bazı OEM ROM'larında bu çağrı kısıtlanmış olabilir; sessizce yut -
            // dinleyici zaten sistemin kendi zamanlamasında yeniden bağlanır.
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        super.onNotificationRemoved(sbn)
        val conversationKey = sbn.groupKey ?: sbn.key
        lastSignaturePerKey.remove(conversationKey)
        lastTriggerAtPerKey.remove(conversationKey)
    }

    companion object {
        private const val DUPLICATE_COOLDOWN_MS = 1200L
    }
}
