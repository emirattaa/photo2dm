package com.edgelightplus.app

object Prefs {
    const val NAME = "edge_light_plus_prefs"
    const val KEY_ENABLED = "enabled"
}
