package com.edgelightplus.app

object Prefs {
    const val NAME = "edge_light_plus_prefs"
    const val KEY_ENABLED = "enabled"
    const val KEY_ONLY_MATCHED_RULES = "only_matched_rules"
}
