package com.edgelightplus.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * WHY THIS EXISTS:
 * NotificationListenerService is a *bound* service - Android is free to unbind and
 * kill the whole app process whenever it wants to reclaim memory, especially on
 * Samsung (One UI's separate "sleeping apps" / RAM Plus memory management on top of
 * stock Android's battery optimization). When that happens, notifications stop
 * triggering the glow until something wakes the process back up.
 *
 * A *foreground* service with an ongoing (even silent, minimal-priority)
 * notification is treated very differently by the OS: it's one of the last things
 * killed, and Samsung's sleep/deep-sleep lists generally leave apps with an active
 * foreground service alone. Running one for as long as the listener is enabled is
 * the standard trick most edge-lighting/call-recording/etc. apps use to actually
 * survive in the background.
 */
class KeepAliveForegroundService : Service() {

    override fun onCreate() {
        super.onCreate()
        createChannelIfNeeded()
        startForeground(NOTIFICATION_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // START_STICKY: if the system still kills us under memory pressure, ask it
        // to recreate this service (with a null intent) as soon as resources free up.
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildNotification() =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.keep_alive_title))
            .setContentText(getString(R.string.keep_alive_text))
            .setSmallIcon(android.R.drawable.presence_online)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()

    private fun createChannelIfNeeded() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java) ?: return
        if (manager.getNotificationChannel(CHANNEL_ID) != null) return
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.keep_alive_channel_name),
            NotificationManager.IMPORTANCE_MIN
        ).apply {
            description = getString(R.string.keep_alive_channel_description)
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)
    }

    companion object {
        private const val CHANNEL_ID = "edge_light_plus_keep_alive"
        private const val NOTIFICATION_ID = 1001

        fun start(context: android.content.Context) {
            val intent = Intent(context, KeepAliveForegroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }
}
