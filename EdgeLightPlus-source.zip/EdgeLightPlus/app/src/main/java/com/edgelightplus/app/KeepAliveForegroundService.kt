package com.edgelightplus.app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationCompat

/**
 * WHY THIS EXISTS:
 * NotificationListenerService is a *bound* service - Android is free to unbind and
 * kill the whole app process whenever it wants to reclaim memory, especially on
 * Samsung (One UI's separate "sleeping apps" / RAM Plus memory management on top of
 * stock Android's battery optimization). When that happens, notifications stop
 * triggering the glow until something wakes the process back up.
 *
 * A *foreground* service with an ongoing (even silent, minimal-priority)
 * notification is treated very differently by the OS: it's one of the last things
 * killed, and Samsung's sleep/deep-sleep lists generally leave apps with an active
 * foreground service alone. Running one for as long as the listener is enabled is
 * the standard trick most edge-lighting/call-recording/etc. apps use to actually
 * survive in the background.
 */
class KeepAliveForegroundService : Service() {

    override fun onCreate() {
        super.onCreate()
        createChannelIfNeeded()
        startForeground(NOTIFICATION_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // START_STICKY: if the system still kills us under memory pressure, ask it
        // to recreate this service (with a null intent) as soon as resources free up.
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    /**
     * Uygulama son uygulamalar listesinden sürüklenip kapatıldığında bazı
     * OEM ROM'ları görev (task) ile ilişkili servisleri de öldürür. Hâlâ
     * etkinse kendimizi hemen yeniden başlatmayı deniyoruz.
     */
    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        if (isStillWanted()) {
            scheduleWatchdogRestart()
        }
    }

    /**
     * Ekstra güvenlik ağı: sistem yine de bizi öldürürse (agresif OEM RAM
     * temizleyicileri START_STICKY'yi bile yok sayabiliyor), birkaç saniye
     * sonra kendimizi yeniden başlatacak bir alarm kuruyoruz.
     */
    override fun onDestroy() {
        super.onDestroy()
        if (isStillWanted()) {
            scheduleWatchdogRestart()
        }
    }

    private fun isStillWanted(): Boolean {
        val prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
        if (!prefs.getBoolean(Prefs.KEY_ENABLED, true)) return false
        val flat = android.provider.Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return flat?.contains(packageName) == true
    }

    private fun scheduleWatchdogRestart() {
        try {
            val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val restartIntent = Intent(this, WatchdogReceiver::class.java)
            val pendingIntent = PendingIntent.getBroadcast(
                this, WATCHDOG_REQUEST_CODE, restartIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            // Kasıtlı olarak "exact" değil: Android 12+'ta tam zamanlı alarmlar ayrı
            // bir kullanıcı izni gerektiriyor. Birkaç saniyelik gecikme burada
            // sorun değil - bu sadece bir yedek/watchdog mekanizması.
            val triggerAt = SystemClock.elapsedRealtime() + WATCHDOG_DELAY_MS
            alarmManager.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pendingIntent)
        } catch (_: Exception) {
            // Alarm izinleri kısıtlanmışsa sessizce vazgeç; bir sonraki bildirim/
            // dinleyici yeniden bağlantısı zaten servisi tekrar tetikleyecektir.
        }
    }

    private fun buildNotification() =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.keep_alive_title))
            .setContentText(getString(R.string.keep_alive_text))
            .setSmallIcon(android.R.drawable.presence_online)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()

    private fun createChannelIfNeeded() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java) ?: return
        if (manager.getNotificationChannel(CHANNEL_ID) != null) return
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.keep_alive_channel_name),
            NotificationManager.IMPORTANCE_MIN
        ).apply {
            description = getString(R.string.keep_alive_channel_description)
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)
    }

    companion object {
        private const val CHANNEL_ID = "edge_light_plus_keep_alive"
        private const val NOTIFICATION_ID = 1001
        private const val WATCHDOG_REQUEST_CODE = 2001
        private const val WATCHDOG_DELAY_MS = 5_000L

        fun start(context: android.content.Context) {
            val intent = Intent(context, KeepAliveForegroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }
}
