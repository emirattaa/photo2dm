package com.edgelightplus.app

import android.animation.Animator
import android.animation.AnimatorSet
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.OvershootInterpolator

/**
 * Draws either a glowing edge gradient (default) or a pulsing heart (for rules the
 * user set up for a specific person/keyword), and animates it in, then out.
 */
class EdgeGlowView(
    context: Context,
    private val color: Int,
    private val shape: GlowShape = GlowShape.EDGE,
    private val onFinished: () -> Unit
) : View(context) {

    private var thicknessPx: Float = 0f
    private var alphaFraction: Float = 0f

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    private val maxThicknessPx: Float = context.resources.displayMetrics.density * 36f

    init {
        setLayerType(LAYER_TYPE_HARDWARE, null)
    }

    fun startGlowAnimation() {
        if (shape == GlowShape.HEART) {
            startHeartAnimation()
            return
        }
        val growIn = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 450
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener {
                val f = it.animatedValue as Float
                thicknessPx = maxThicknessPx * f
                alphaFraction = f
                invalidate()
            }
        }

        val hold = ValueAnimator.ofFloat(1f, 1f).apply {
            duration = 900
        }

        val fadeOut = ValueAnimator.ofFloat(1f, 0f).apply {
            duration = 600
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener {
                val f = it.animatedValue as Float
                thicknessPx = maxThicknessPx * f
                alphaFraction = f
                invalidate()
            }
        }

        val set = AnimatorSet()
        set.playSequentially(growIn, hold, fadeOut)
        set.addListener(object : Animator.AnimatorListener {
            override fun onAnimationStart(animation: Animator) {}
            override fun onAnimationEnd(animation: Animator) {
                onFinished()
            }
            override fun onAnimationCancel(animation: Animator) {}
            override fun onAnimationRepeat(animation: Animator) {}
        })
        set.start()
    }

    /** 0 = not started/gone, 1 = fully grown. Reused as the heart's scale progress. */
    private var heartScale: Float = 0f

    private fun startHeartAnimation() {
        val growIn = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 500
            interpolator = OvershootInterpolator(2.2f)
            addUpdateListener {
                heartScale = it.animatedValue as Float
                alphaFraction = (heartScale).coerceIn(0f, 1f)
                invalidate()
            }
        }

        val hold = ValueAnimator.ofFloat(1f, 1f).apply { duration = 800 }

        val fadeOut = ValueAnimator.ofFloat(1f, 0f).apply {
            duration = 500
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener {
                val f = it.animatedValue as Float
                alphaFraction = f
                invalidate()
            }
        }

        val set = AnimatorSet()
        set.playSequentially(growIn, hold, fadeOut)
        set.addListener(object : Animator.AnimatorListener {
            override fun onAnimationStart(animation: Animator) {}
            override fun onAnimationEnd(animation: Animator) {
                onFinished()
            }
            override fun onAnimationCancel(animation: Animator) {}
            override fun onAnimationRepeat(animation: Animator) {}
        })
        set.start()
    }

    private fun heartPath(cx: Float, cy: Float, size: Float): Path {
        // Classic two-bezier-lobe heart, built around (cx, cy) at the given size.
        val path = Path()
        path.moveTo(cx, cy + size * 0.3f)
        path.cubicTo(
            cx - size, cy - size * 0.6f,
            cx - size * 0.5f, cy - size * 1.4f,
            cx, cy - size * 0.5f
        )
        path.cubicTo(
            cx + size * 0.5f, cy - size * 1.4f,
            cx + size, cy - size * 0.6f,
            cx, cy + size * 0.3f
        )
        path.close()
        return path
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        if (shape == GlowShape.HEART) {
            drawHeart(canvas)
            return
        }

        if (thicknessPx <= 0f || width == 0 || height == 0) return

        val alpha = (alphaFraction.coerceIn(0f, 1f) * 255).toInt()
        val colorWithAlpha = (color and 0x00FFFFFF) or (alpha shl 24)
        val transparent = color and 0x00FFFFFF

        // Top edge
        paint.shader = LinearGradient(
            0f, 0f, 0f, thicknessPx,
            colorWithAlpha, transparent, Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, width.toFloat(), thicknessPx, paint)

        // Bottom edge
        paint.shader = LinearGradient(
            0f, height.toFloat(), 0f, height - thicknessPx,
            colorWithAlpha, transparent, Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, height - thicknessPx, width.toFloat(), height.toFloat(), paint)

        // Left edge
        paint.shader = LinearGradient(
            0f, 0f, thicknessPx, 0f,
            colorWithAlpha, transparent, Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, thicknessPx, height.toFloat(), paint)

        // Right edge
        paint.shader = LinearGradient(
            width.toFloat(), 0f, width - thicknessPx, 0f,
            colorWithAlpha, transparent, Shader.TileMode.CLAMP
        )
        canvas.drawRect(width - thicknessPx, 0f, width.toFloat(), height.toFloat(), paint)
    }

    private fun drawHeart(canvas: Canvas) {
        if (heartScale <= 0f || width == 0 || height == 0) return

        val alpha = (alphaFraction.coerceIn(0f, 1f) * 255).toInt()
        val colorWithAlpha = (color and 0x00FFFFFF) or (alpha shl 24)

        val cx = width / 2f
        val cy = height * 0.22f
        val baseSize = context.resources.displayMetrics.density * 46f
        val size = baseSize * heartScale.coerceIn(0f, 1.15f)

        // Soft glow behind the heart.
        paint.shader = RadialGradient(
            cx, cy, size * 2.2f,
            colorWithAlpha, color and 0x00FFFFFF, Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, size * 2.2f, paint)

        // Solid heart on top.
        paint.shader = null
        paint.color = colorWithAlpha
        canvas.drawPath(heartPath(cx, cy, size), paint)
    }
}
