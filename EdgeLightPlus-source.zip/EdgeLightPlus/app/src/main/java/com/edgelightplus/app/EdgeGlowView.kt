package com.edgelightplus.app

import android.animation.Animator
import android.animation.AnimatorSet
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator

/**
 * Draws a glowing gradient around all four edges of the screen and animates its
 * thickness/alpha in, then out. Roughly mimics "edge lighting" style notification
 * effects.
 */
class EdgeGlowView(
    context: Context,
    private val color: Int,
    private val onFinished: () -> Unit
) : View(context) {

    private var thicknessPx: Float = 0f
    private var alphaFraction: Float = 0f

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    private val maxThicknessPx: Float = context.resources.displayMetrics.density * 36f

    init {
        setLayerType(LAYER_TYPE_HARDWARE, null)
    }

    fun startGlowAnimation() {
        val growIn = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 450
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener {
                val f = it.animatedValue as Float
                thicknessPx = maxThicknessPx * f
                alphaFraction = f
                invalidate()
            }
        }

        val hold = ValueAnimator.ofFloat(1f, 1f).apply {
            duration = 900
        }

        val fadeOut = ValueAnimator.ofFloat(1f, 0f).apply {
            duration = 600
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener {
                val f = it.animatedValue as Float
                thicknessPx = maxThicknessPx * f
                alphaFraction = f
                invalidate()
            }
        }

        val set = AnimatorSet()
        set.playSequentially(growIn, hold, fadeOut)
        set.addListener(object : Animator.AnimatorListener {
            override fun onAnimationStart(animation: Animator) {}
            override fun onAnimationEnd(animation: Animator) {
                onFinished()
            }
            override fun onAnimationCancel(animation: Animator) {}
            override fun onAnimationRepeat(animation: Animator) {}
        })
        set.start()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (thicknessPx <= 0f || width == 0 || height == 0) return

        val alpha = (alphaFraction.coerceIn(0f, 1f) * 255).toInt()
        val colorWithAlpha = (color and 0x00FFFFFF) or (alpha shl 24)
        val transparent = color and 0x00FFFFFF

        // Top edge
        paint.shader = LinearGradient(
            0f, 0f, 0f, thicknessPx,
            colorWithAlpha, transparent, Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, width.toFloat(), thicknessPx, paint)

        // Bottom edge
        paint.shader = LinearGradient(
            0f, height.toFloat(), 0f, height - thicknessPx,
            colorWithAlpha, transparent, Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, height - thicknessPx, width.toFloat(), height.toFloat(), paint)

        // Left edge
        paint.shader = LinearGradient(
            0f, 0f, thicknessPx, 0f,
            colorWithAlpha, transparent, Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, thicknessPx, height.toFloat(), paint)

        // Right edge
        paint.shader = LinearGradient(
            width.toFloat(), 0f, width - thicknessPx, 0f,
            colorWithAlpha, transparent, Shader.TileMode.CLAMP
        )
        canvas.drawRect(width - thicknessPx, 0f, width.toFloat(), height.toFloat(), paint)
    }
}
