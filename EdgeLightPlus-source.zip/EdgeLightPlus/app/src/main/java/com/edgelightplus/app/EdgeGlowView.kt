package com.edgelightplus.app

import android.animation.Animator
import android.animation.AnimatorSet
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.AccelerateInterpolator
import android.view.animation.BounceInterpolator
import android.view.animation.DecelerateInterpolator

/**
 * Draws either a glowing, "breathing" edge gradient (default, inspired by Edge
 * Lighting+'s pulsing edge glow) or a heart that drops in from the top of the
 * screen and bounces into place (for rules the user set up for a specific
 * person/keyword), then animates it out.
 */
class EdgeGlowView(
    context: Context,
    private val color: Int,
    private val shape: GlowShape = GlowShape.EDGE,
    private val onFinished: () -> Unit
) : View(context) {

    // ---- Edge glow state ----
    private var thicknessPx: Float = 0f
    private var alphaFraction: Float = 0f

    // ---- Heart state ----
    private var heartY: Float = 0f          // current vertical position (px)
    private var heartScale: Float = 0f      // current scale (squash/stretch aware)
    private var heartScaleX: Float = 1f
    private var heartAlpha: Float = 0f

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    private val density = context.resources.displayMetrics.density
    private val maxThicknessPx: Float = density * 34f
    private val cornerRadiusPx: Float = density * 26f

    init {
        setLayerType(LAYER_TYPE_HARDWARE, null)
    }

    fun startGlowAnimation() {
        if (shape == GlowShape.HEART) {
            startHeartAnimation()
        } else {
            startEdgeAnimation()
        }
    }

    // ============================== EDGE GLOW ==============================

    private fun startEdgeAnimation() {
        // 1) Grow in from nothing to full thickness.
        val growIn = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 380
            interpolator = DecelerateInterpolator(1.6f)
            addUpdateListener {
                val f = it.animatedValue as Float
                thicknessPx = maxThicknessPx * f
                alphaFraction = f
                invalidate()
            }
        }

        // 2) "Breathing" pulse - thickness gently swells and settles twice while
        //    held, similar to how Edge Lighting+ pulses rather than staying static.
        val breatheOut = ValueAnimator.ofFloat(1f, 1.22f).apply {
            duration = 320
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener {
                thicknessPx = maxThicknessPx * (it.animatedValue as Float)
                invalidate()
            }
        }
        val breatheIn = ValueAnimator.ofFloat(1.22f, 1f).apply {
            duration = 320
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener {
                thicknessPx = maxThicknessPx * (it.animatedValue as Float)
                invalidate()
            }
        }
        val breatheOut2 = ValueAnimator.ofFloat(1f, 1.12f).apply {
            duration = 260
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener {
                thicknessPx = maxThicknessPx * (it.animatedValue as Float)
                invalidate()
            }
        }
        val breatheIn2 = ValueAnimator.ofFloat(1.12f, 1f).apply {
            duration = 260
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener {
                thicknessPx = maxThicknessPx * (it.animatedValue as Float)
                invalidate()
            }
        }

        // 3) Fade out.
        val fadeOut = ValueAnimator.ofFloat(1f, 0f).apply {
            duration = 550
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener {
                val f = it.animatedValue as Float
                thicknessPx = maxThicknessPx * f
                alphaFraction = f
                invalidate()
            }
        }

        val set = AnimatorSet()
        set.playSequentially(growIn, breatheOut, breatheIn, breatheOut2, breatheIn2, fadeOut)
        set.addListener(simpleEndListener())
        set.start()
    }

    // ============================== HEART ==============================

    private fun startHeartAnimation() {
        heartAlpha = 0f

        // 1) Fall in from above the screen with a bounce landing - the visual the
        //    user asked for ("kalp üstten düşmeli").
        val fall = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 700
            interpolator = BounceInterpolator()
            addUpdateListener {
                val f = it.animatedValue as Float
                heartYFraction = f
                heartAlpha = (f * 3f).coerceIn(0f, 1f) // fade in fast, before the bounce settles
                invalidate()
            }
        }

        // Slight squash on landing handled inside heartYFraction listener via scale.
        val squash = ValueAnimator.ofFloat(1f, 0.8f, 1.08f, 1f).apply {
            duration = 260
            startDelay = 480 // roughly when the bounce first touches down
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener {
                heartScaleX = it.animatedValue as Float
                invalidate()
            }
        }

        // 2) Gentle idle pulse while held, like a heartbeat.
        val beat1 = ValueAnimator.ofFloat(1f, 1.15f).apply {
            duration = 180
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { heartScale = it.animatedValue as Float; invalidate() }
        }
        val beat1Back = ValueAnimator.ofFloat(1.15f, 1f).apply {
            duration = 180
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { heartScale = it.animatedValue as Float; invalidate() }
        }
        val beatPause = ValueAnimator.ofFloat(1f, 1f).apply { duration = 220 }
        val beat2 = ValueAnimator.ofFloat(1f, 1.15f).apply {
            duration = 180
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { heartScale = it.animatedValue as Float; invalidate() }
        }
        val beat2Back = ValueAnimator.ofFloat(1.15f, 1f).apply {
            duration = 180
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { heartScale = it.animatedValue as Float; invalidate() }
        }
        val hold = ValueAnimator.ofFloat(1f, 1f).apply { duration = 400 }

        // 3) Fade out while drifting slightly further down.
        val fadeOut = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 500
            interpolator = AccelerateInterpolator()
            addUpdateListener {
                val f = it.animatedValue as Float
                heartAlpha = 1f - f
                heartYFraction = 1f + f * 0.15f
                invalidate()
            }
        }

        heartScale = 1f

        val beatSequence = AnimatorSet()
        beatSequence.playSequentially(beat1, beat1Back, beatPause, beat2, beat2Back, hold)

        val fallGroup = AnimatorSet()
        fallGroup.playTogether(fall, squash)

        val set = AnimatorSet()
        set.playSequentially(fallGroup, beatSequence, fadeOut)
        set.addListener(simpleEndListener())
        set.start()
    }

    /** 0 = just above the screen, 1 = resting position, >1 = falling further past it. */
    private var heartYFraction: Float = 0f

    private fun heartPath(cx: Float, cy: Float, size: Float, scaleX: Float): Path {
        val path = Path()
        val sx = size * scaleX
        path.moveTo(cx, cy + size * 0.3f)
        path.cubicTo(
            cx - sx, cy - size * 0.6f,
            cx - sx * 0.5f, cy - size * 1.4f,
            cx, cy - size * 0.5f
        )
        path.cubicTo(
            cx + sx * 0.5f, cy - size * 1.4f,
            cx + sx, cy - size * 0.6f,
            cx, cy + size * 0.3f
        )
        path.close()
        return path
    }

    private fun simpleEndListener() = object : Animator.AnimatorListener {
        override fun onAnimationStart(animation: Animator) {}
        override fun onAnimationEnd(animation: Animator) {
            onFinished()
        }
        override fun onAnimationCancel(animation: Animator) {}
        override fun onAnimationRepeat(animation: Animator) {}
    }

    // ============================== DRAWING ==============================

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        if (shape == GlowShape.HEART) {
            drawHeart(canvas)
            return
        }

        if (thicknessPx <= 0f || width == 0 || height == 0) return

        val alpha = (alphaFraction.coerceIn(0f, 1f) * 255).toInt()
        val colorWithAlpha = (color and 0x00FFFFFF) or (alpha shl 24)
        val transparent = color and 0x00FFFFFF

        // Top edge
        paint.shader = LinearGradient(
            0f, 0f, 0f, thicknessPx,
            colorWithAlpha, transparent, Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, width.toFloat(), thicknessPx, paint)

        // Bottom edge
        paint.shader = LinearGradient(
            0f, height.toFloat(), 0f, height - thicknessPx,
            colorWithAlpha, transparent, Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, height - thicknessPx, width.toFloat(), height.toFloat(), paint)

        // Left edge
        paint.shader = LinearGradient(
            0f, 0f, thicknessPx, 0f,
            colorWithAlpha, transparent, Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, thicknessPx, height.toFloat(), paint)

        // Right edge
        paint.shader = LinearGradient(
            width.toFloat(), 0f, width - thicknessPx, 0f,
            colorWithAlpha, transparent, Shader.TileMode.CLAMP
        )
        canvas.drawRect(width - thicknessPx, 0f, width.toFloat(), height.toFloat(), paint)

        // Rounded corner blobs so the glow follows the phone's rounded screen
        // corners instead of looking like four hard-edged rectangles.
        paint.shader = null
        val cornerAlpha = (alpha * 0.9f).toInt().coerceIn(0, 255)
        val cornerColor = (color and 0x00FFFFFF) or (cornerAlpha shl 24)
        val r = thicknessPx * 1.15f
        listOf(
            0f to 0f,
            width.toFloat() to 0f,
            0f to height.toFloat(),
            width.toFloat() to height.toFloat()
        ).forEach { (cx, cy) ->
            paint.shader = RadialGradient(cx, cy, r, cornerColor, transparent, Shader.TileMode.CLAMP)
            canvas.drawCircle(cx, cy, r, paint)
        }
    }

    private fun drawHeart(canvas: Canvas) {
        if (heartAlpha <= 0f || width == 0 || height == 0) return

        val alpha = (heartAlpha.coerceIn(0f, 1f) * 255).toInt()
        val colorWithAlpha = (color and 0x00FFFFFF) or (alpha shl 24)

        val cx = width / 2f
        val restY = height * 0.22f
        val startY = -height * 0.25f
        val cy = startY + (restY - startY) * heartYFraction.coerceAtMost(1.3f)

        val baseSize = density * 46f
        val size = baseSize * heartScale

        // Soft glow behind the heart.
        paint.shader = RadialGradient(
            cx, cy, size * 2.2f,
            colorWithAlpha, color and 0x00FFFFFF, Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, size * 2.2f, paint)

        // Solid heart on top (slightly squashed horizontally right after landing).
        paint.shader = null
        paint.color = colorWithAlpha
        canvas.drawPath(heartPath(cx, cy, size, heartScaleX), paint)
    }
}
