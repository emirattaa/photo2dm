package com.edgelightplus.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.CompoundButton
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var enableSwitch: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        enableSwitch = findViewById(R.id.enableSwitch)

        val notifButton = findViewById<Button>(R.id.btnNotificationAccess)
        val overlayButton = findViewById<Button>(R.id.btnOverlayAccess)
        val testButton = findViewById<Button>(R.id.btnTestGlow)

        val prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
        enableSwitch.isChecked = prefs.getBoolean(Prefs.KEY_ENABLED, true)
        enableSwitch.setOnCheckedChangeListener { _: CompoundButton, isChecked: Boolean ->
            prefs.edit().putBoolean(Prefs.KEY_ENABLED, isChecked).apply()
        }

        notifButton.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        overlayButton.setOnClickListener {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }

        testButton.setOnClickListener {
            EdgeOverlayManager.showGlow(applicationContext, 0xFFE1306C.toInt())
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        val overlayGranted = EdgeOverlayManager.canDrawOverlays(this)
        val notifGranted = isNotificationListenerEnabled()

        statusText.text = buildString {
            append(if (notifGranted) "✔ Bildirim erişimi verildi\n" else "✘ Bildirim erişimi GEREKLİ\n")
            append(if (overlayGranted) "✔ Üzerine çizme izni verildi" else "✘ Üzerine çizme izni GEREKLİ")
        }
    }

    private fun isNotificationListenerEnabled(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return flat?.contains(packageName) == true
    }
}
