package com.edgelightplus.app

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.CompoundButton
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var enableSwitch: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        enableSwitch = findViewById(R.id.enableSwitch)
        val onlyMatchedSwitch = findViewById<Switch>(R.id.onlyMatchedSwitch)

        val notifButton = findViewById<Button>(R.id.btnNotificationAccess)
        val overlayButton = findViewById<Button>(R.id.btnOverlayAccess)
        val batteryButton = findViewById<Button>(R.id.btnBatteryOptimization)
        val autostartButton = findViewById<Button>(R.id.btnAutostart)
        val rulesButton = findViewById<Button>(R.id.btnRules)
        val testButton = findViewById<Button>(R.id.btnTestGlow)
        val testHeartButton = findViewById<Button>(R.id.btnTestHeart)

        val prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
        enableSwitch.isChecked = prefs.getBoolean(Prefs.KEY_ENABLED, true)
        enableSwitch.setOnCheckedChangeListener { _: CompoundButton, isChecked: Boolean ->
            prefs.edit().putBoolean(Prefs.KEY_ENABLED, isChecked).apply()
            if (isChecked && isNotificationListenerEnabled()) {
                KeepAliveForegroundService.start(applicationContext)
            }
        }

        onlyMatchedSwitch.isChecked = prefs.getBoolean(Prefs.KEY_ONLY_MATCHED_RULES, true)
        onlyMatchedSwitch.setOnCheckedChangeListener { _: CompoundButton, isChecked: Boolean ->
            prefs.edit().putBoolean(Prefs.KEY_ONLY_MATCHED_RULES, isChecked).apply()
        }

        notifButton.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        overlayButton.setOnClickListener {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }

        batteryButton.setOnClickListener {
            requestIgnoreBatteryOptimizations()
        }

        // Standart pil izni yeterli olmayan OEM'lerde (Xiaomi/Oppo/Vivo/Huawei/
        // Samsung vb.) üreticiye özel "Otomatik Başlatma" ekranını doğrudan açmayı
        // dener; bulamazsa uygulama detay ekranına düşer. Bu adım gerçekten
        // kullanıcının elle onaylaması gereken bir izin, kod bunu otomatik
        // veremiyor - bu yüzden buton olarak açıkça isteniyor.
        autostartButton.setOnClickListener {
            OemAutostart.openAutostartSettings(this)
        }

        rulesButton.setOnClickListener {
            startActivity(Intent(this, RulesActivity::class.java))
        }

        testButton.setOnClickListener {
            EdgeOverlayManager.showGlow(applicationContext, 0xFFE1306C.toInt())
        }

        testHeartButton.setOnClickListener {
            EdgeOverlayManager.showGlow(applicationContext, 0xFFE1306C.toInt(), GlowShape.HEART)
        }

        requestNotificationPermissionIfNeeded()
        if (isNotificationListenerEnabled()) {
            KeepAliveForegroundService.start(applicationContext)
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
        val granted = ContextCompat.checkSelfPermission(
            this, android.Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
        if (!granted) {
            ActivityCompat.requestPermissions(
                this, arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1001
            )
        }
    }

    /**
     * Samsung (ve stok Android) arka planda kalan uygulamaları/bildirim dinleyici
     * servislerini pil tasarrufu için kapatabiliyor. Bu, uygulamayı o listeden
     * çıkarmayı istemenin standart yolu. Kullanıcı yine de cihaza göre elle
     * Ayarlar > Pil > Arka Plan Kullanımı bölümüne bakmak isteyebilir; bu yüzden
     * ek olarak uygulama detay ekranına da yönlendiriyoruz.
     */
    private fun requestIgnoreBatteryOptimizations() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            // Zaten istisnada; kullanıcıyı uygulama detay ekranına yönlendirip
            // Samsung'a özgü "Uyku moduna alma listesi" ayarını manuel kontrol etmesini kolaylaştır.
            startActivity(
                Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:$packageName")
                )
            )
            return
        }
        try {
            startActivity(
                Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")
                )
            )
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
        if (isNotificationListenerEnabled()) {
            KeepAliveForegroundService.start(applicationContext)
        }
    }

    private fun updateStatus() {
        val overlayGranted = EdgeOverlayManager.canDrawOverlays(this)
        val notifGranted = isNotificationListenerEnabled()
        val batteryExempt = isIgnoringBatteryOptimizations()

        statusText.text = buildString {
            append(if (notifGranted) "✔ Bildirim erişimi verildi\n" else "✘ Bildirim erişimi GEREKLİ\n")
            append(if (overlayGranted) "✔ Üzerine çizme izni verildi\n" else "✘ Üzerine çizme izni GEREKLİ\n")
            append(if (batteryExempt) "✔ Pil optimizasyonu istisnası verildi" else "✘ Pil optimizasyonu istisnası GEREKLİ (arka planda çalışması için)")
            if (OemAutostart.isKnownRestrictiveOem()) {
                append("\n")
                append(getString(R.string.autostart_hint, OemAutostart.manufacturerDisplayName()))
            }
        }
    }

    private fun isIgnoringBatteryOptimizations(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(packageName)
    }

    private fun isNotificationListenerEnabled(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return flat?.contains(packageName) == true
    }
}
