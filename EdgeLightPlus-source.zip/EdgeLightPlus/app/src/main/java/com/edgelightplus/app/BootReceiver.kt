package com.edgelightplus.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return

        val prefs = context.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(Prefs.KEY_ENABLED, true)) return

        val flat = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners")
        val notifGranted = flat?.contains(context.packageName) == true
        if (notifGranted) {
            KeepAliveForegroundService.start(context)
        }
    }
}
