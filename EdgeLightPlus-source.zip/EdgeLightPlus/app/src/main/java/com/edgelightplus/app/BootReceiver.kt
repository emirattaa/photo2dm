package com.edgelightplus.app

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.service.notification.NotificationListenerService

/**
 * Uygulamayı/servisi şu 3 durumda "uyandırır":
 *  1) Cihaz açılışı (BOOT_COMPLETED / QUICKBOOT_POWERON)
 *  2) APK GÜNCELLEMESİ (MY_PACKAGE_REPLACED) - ASIL DÜZELTME BURADA:
 *     Android, bir uygulama güncellendiğinde onun NotificationListenerService
 *     bağlantısını otomatik olarak koparır ve normal şartlarda cihaz yeniden
 *     başlatılana ya da kullanıcı Ayarlar'dan izni kapatıp tekrar açana kadar
 *     GERİ BAĞLAMAZ. KeepAliveForegroundService de aynı şekilde güncelleme
 *     kurulumuyla birlikte öldürülür ve kendi kendine geri gelmez. Önceki
 *     sürümde bu senaryo hiç ele alınmıyordu; bu yüzden "APK'yi güncelle ->
 *     arka planda kapanıyor" şikayeti oluyordu: uygulama açıkken çalışıyor
 *     gibi görünüyor ama arka planda bildirim geldiğinde artık hiçbir şey
 *     tetiklenmiyordu, çünkü dinleyici hâlâ eski (kopmuş) bağlantıdaydı.
 *  3) requestRebind çağrısı ile sistemin dinleyiciyi hemen yeniden bağlamasını
 *     tetikliyoruz; boot/güncelleme sonrası saniyeler içinde tekrar aktif hale
 *     geliyor.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val relevantAction = intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == "android.intent.action.QUICKBOOT_POWERON" ||
            intent.action == "com.htc.intent.action.QUICKBOOT_POWERON" ||
            intent.action == Intent.ACTION_MY_PACKAGE_REPLACED
        if (!relevantAction) return

        val prefs = context.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(Prefs.KEY_ENABLED, true)) return

        if (!isNotificationListenerGranted(context)) return

        KeepAliveForegroundService.start(context)

        // Sistemi, dinleyiciyi hemen (sonraki bildirime kadar beklemeden)
        // yeniden bağlamaya zorla. Android 9+ (API 28+) üzerinde kullanılabilir;
        // minSdk 24 olduğu için versiyon kontrolü şart.
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
            try {
                NotificationListenerService.requestRebind(
                    ComponentName(context, EdgeNotificationListenerService::class.java)
                )
            } catch (_: Exception) {
                // Bazı OEM ROM'larında bu çağrı kısıtlanmış olabilir; sessizce yut,
                // dinleyici zaten bir sonraki bildirimde ya da sistemin kendi
                // zamanlamasında yeniden bağlanacaktır.
            }
        }
    }

    private fun isNotificationListenerGranted(context: Context): Boolean {
        val flat = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners")
        return flat?.contains(context.packageName) == true
    }
}
