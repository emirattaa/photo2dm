# Edge Light Plus

Instagram gibi bildirimleri **gruplayan/stackleyen** uygulamalarda çalışan bir kenar
ışığı (edge lighting) bildirim animasyonu uygulaması.

## Instagram sorunu nasıl çözüldü?

`EdgeNotificationListenerService.kt` içinde:

- Grup özet bildirimleri (`FLAG_GROUP_SUMMARY`) artık **yok sayılmıyor**, içerikleri okunuyor.
- `Notification.EXTRA_TEXT_LINES` (Instagram/WhatsApp/Gmail'in stack'lenmiş mesajlar için
  kullandığı liste) okunup en son satır alınıyor.
- Her `onNotificationPosted` çağrısında içerik "imzası" hesaplanıp konuşma bazında
  (sbn.groupKey) saklanıyor; imza değiştiyse (yeni mesaj geldiyse) animasyon tetikleniyor.
  Bu sayede Android'in aynı bildirimi güncelleyip yeniden postalamadığı durumlar da yakalanıyor.

## Kurulum / kullanım

1. APK'yı yükleyin.
2. Uygulamayı açın, **Bildirim Erişimine İzin Ver** ve **Üzerine Çizme İznini Ver**
   butonlarına basıp izinleri verin.
3. Anahtarı (switch) açık bırakın. Artık gelen bildirimlerde ekran kenarlarında
   parlama animasyonu görünecek.
4. **Test Animasyonu Göster** ile izinler doğru verilmiş mi kontrol edebilirsiniz.

## Notlar

- Bu bir MVP'dir (minimum çalışır sürüm); renk paleti, animasyon eğrisi ve
  uygulama başına özelleştirme kolayca genişletilebilir
  (`KNOWN_APP_COLORS` haritasına yeni paket adları ekleyerek).
- Derleme ortamında (bu sohbet) internet erişimi olmadığı için proje burada
  gerçek bir Gradle/Android SDK ile derlenip test edilemedi; GitHub Actions
  workflow'u bunu sizin için CI ortamında yapacak.

## Sürüm notu: "APK'yi güncelleyince arka planda kapanıyor" düzeltmesi

Kök neden: Android, bir uygulama güncellendiğinde `NotificationListenerService`
bağlantısını otomatik olarak koparıyor ve cihaz yeniden başlatılana ya da
kullanıcı izni elle kapatıp açana kadar geri bağlamıyor. Eski `BootReceiver`
sadece `BOOT_COMPLETED` dinliyordu, güncelleme senaryosunu hiç ele almıyordu.

Eklenenler:
- `BootReceiver` artık `MY_PACKAGE_REPLACED` (+ bazı OEM'lerin kullandığı
  `QUICKBOOT_POWERON`) olayını da dinliyor ve güncelleme sonrası hem
  `KeepAliveForegroundService`'i yeniden başlatıyor hem de
  `NotificationListenerService.requestRebind()` ile dinleyiciyi anında
  yeniden bağlıyor.
- `KeepAliveForegroundService`, `onTaskRemoved`/`onDestroy` sırasında
  `WatchdogReceiver` üzerinden kendini birkaç saniye içinde yeniden
  başlatan bir yedek alarm kuruyor (agresif OEM RAM temizleyicilerine karşı).
- Yeni `OemAutostart` yardımcı sınıfı: Xiaomi/Redmi/Poco, Oppo, Vivo/iQOO,
  Huawei/Honor, Samsung, Asus, LeEco/Letv ve Meizu için üreticiye özel
  "Otomatik Başlatma / Korumalı Uygulamalar" ekranını doğrudan açmaya
  çalışıyor (bulunamazsa uygulama detay ekranına düşüyor). Bu, Android'in
  standart pil izni API'sinin kapsamadığı, kullanıcının cihazda elle
  onaylaması gereken tek adım - uygulama artık ana ekranda bunu açıkça
  bir buton ve uyarı metni olarak istiyor.
- Ana ekran ve kurallar ekranı Material kart tabanlı bir arayüze
  güncellendi (mor/pembe marka paleti, açık/koyu tema desteği).
