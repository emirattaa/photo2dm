# Edge Light Plus

Instagram gibi bildirimleri **gruplayan/stackleyen** uygulamalarda çalışan bir kenar
ışığı (edge lighting) bildirim animasyonu uygulaması.

## Instagram sorunu nasıl çözüldü?

`EdgeNotificationListenerService.kt` içinde:

- Grup özet bildirimleri (`FLAG_GROUP_SUMMARY`) artık **yok sayılmıyor**, içerikleri okunuyor.
- `Notification.EXTRA_TEXT_LINES` (Instagram/WhatsApp/Gmail'in stack'lenmiş mesajlar için
  kullandığı liste) okunup en son satır alınıyor.
- Her `onNotificationPosted` çağrısında içerik "imzası" hesaplanıp konuşma bazında
  (sbn.groupKey) saklanıyor; imza değiştiyse (yeni mesaj geldiyse) animasyon tetikleniyor.
  Bu sayede Android'in aynı bildirimi güncelleyip yeniden postalamadığı durumlar da yakalanıyor.

## Kurulum / kullanım

1. APK'yı yükleyin.
2. Uygulamayı açın, **Bildirim Erişimine İzin Ver** ve **Üzerine Çizme İznini Ver**
   butonlarına basıp izinleri verin.
3. Anahtarı (switch) açık bırakın. Artık gelen bildirimlerde ekran kenarlarında
   parlama animasyonu görünecek.
4. **Test Animasyonu Göster** ile izinler doğru verilmiş mi kontrol edebilirsiniz.

## Notlar

- Bu bir MVP'dir (minimum çalışır sürüm); renk paleti, animasyon eğrisi ve
  uygulama başına özelleştirme kolayca genişletilebilir
  (`KNOWN_APP_COLORS` haritasına yeni paket adları ekleyerek).
- Derleme ortamında (bu sohbet) internet erişimi olmadığı için proje burada
  gerçek bir Gradle/Android SDK ile derlenip test edilemedi; GitHub Actions
  workflow'u bunu sizin için CI ortamında yapacak.
