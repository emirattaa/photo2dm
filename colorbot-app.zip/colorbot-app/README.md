# ColorBot — Ekran Renk Eşleştirme Otomasyonu

Bu proje, **AccessibilityService** ve **MediaProjection** kullanarak başka bir
uygulamanın ekranını izleyip, belirlediğiniz noktalardaki renklere göre otomatik
dokunuşlar gönderen bir Android uygulamasıdır.

## Nasıl çalışır?

Kontrol panelinde 4 sürüklenebilir işaretçi vardır:

- **E (mor)** — Hedef uygulamadaki damla/renk-seçici ikonun tam konumu.
- **I (turkuaz)** — Hedef uygulamanın "şu an gereken renk"i gösterdiği pikselin konumu.
- **1 (sarı)** ve **2 (kırmızı)** — Taranacak alanın sol-üst ve sağ-alt köşeleri.

"Başlat" düğmesine bastığınızda döngü şunu yapar:
1. **E** noktasına dokunur.
2. Kısa bir bekleme sonrası ekran görüntüsü alır.
3. **I** noktasındaki rengi okur (bu, "gerekli renk" olur).
4. 1–2 köşeleri arasındaki alanda o renkle **birebir eşleşen** bir piksel arar.
5. Bulamazsa, renk uzaklığı (RGB Öklid mesafesi) en **düşük** olan, yani göze en
   yakın rengi taşıyan pikseli bulur.
6. Bulunan noktaya dokunur ve döngü 700ms sonra tekrar başlar.

## Kurulum sırası (uygulama içinde de anlatılır)

1. **Erişilebilirlik servisini etkinleştirin** (Ayarlar > Erişilebilirlik > ColorBot).
2. **"Diğer uygulamaların üzerine çiz" iznini verin.**
3. **"Ekran Yakalamayı Başlat"** düğmesine basıp sistem izin diyaloğunu onaylayın.
4. **"Kontrol Panelini Aç"** düğmesine basın, işaretçileri hedef uygulamadaki
   doğru noktalara sürükleyin, sonra "Başlat"a basın.

## Önemli notlar

- Bu tür otomasyon araçları, kullandığınız hedef uygulamanın **kullanım
  koşullarını (Terms of Service)** ihlal edebilir; özellikle çevrimiçi
  yarışmalı oyunlarda hesabınızın kısıtlanmasına yol açabilir. Kullanmadan
  önce hedef uygulamanın kurallarını kontrol edin.
- `gradle-wrapper.jar` ikili dosyası bu pakette yoktur (internet erişimi
  gerektirir); ekteki CI/CD workflow dosyası derleme sırasında bunu otomatik
  üretir.
- Renk okuma hassasiyeti `ColorMatcher.kt` içindeki `exactTolerance` ve
  `step` değerleriyle ayarlanabilir; daha yüksek çözünürlüklü taramalar
  daha yavaş ama daha isabetli olur.
