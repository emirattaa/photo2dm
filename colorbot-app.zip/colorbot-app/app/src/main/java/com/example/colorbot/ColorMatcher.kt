package com.example.colorbot

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import kotlin.math.sqrt

data class MatchResult(val x: Int, val y: Int, val color: Int, val exact: Boolean)

object ColorMatcher {

    /**
     * [searchArea] bölgesini [step] aralıklarla tarar.
     * Önce [targetColor] ile TAM eşleşen (toleranslı) bir piksel arar.
     * Bulamazsa, renk uzaklığı en küçük olan pikseli döndürür.
     *
     * [exactTolerance]: "aynı renk" kabul edilecek maksimum renk uzaklığı.
     */
    fun findMatch(
        bitmap: Bitmap,
        searchArea: Rect,
        targetColor: Int,
        step: Int = 4,
        exactTolerance: Double = 12.0
    ): MatchResult? {
        var bestX = -1
        var bestY = -1
        var bestColor = Color.TRANSPARENT
        var bestDistance = Double.MAX_VALUE

        val left = searchArea.left.coerceAtLeast(0)
        val top = searchArea.top.coerceAtLeast(0)
        val right = searchArea.right.coerceAtMost(bitmap.width - 1)
        val bottom = searchArea.bottom.coerceAtMost(bitmap.height - 1)

        var y = top
        while (y <= bottom) {
            var x = left
            while (x <= right) {
                val pixelColor = bitmap.getPixel(x, y)
                val distance = colorDistance(pixelColor, targetColor)

                if (distance <= exactTolerance) {
                    // Tam (toleranslı) eşleşme bulundu, hemen döndür.
                    return MatchResult(x, y, pixelColor, exact = true)
                }

                if (distance < bestDistance) {
                    bestDistance = distance
                    bestX = x
                    bestY = y
                    bestColor = pixelColor
                }
                x += step
            }
            y += step
        }

        return if (bestX >= 0) {
            MatchResult(bestX, bestY, bestColor, exact = false)
        } else {
            null
        }
    }

    /**
     * İki renk arasındaki Öklid uzaklığı (RGB kanallarında).
     */
    fun colorDistance(c1: Int, c2: Int): Double {
        val rDiff = (Color.red(c1) - Color.red(c2)).toDouble()
        val gDiff = (Color.green(c1) - Color.green(c2)).toDouble()
        val bDiff = (Color.blue(c1) - Color.blue(c2)).toDouble()
        return sqrt(rDiff * rDiff + gDiff * gDiff + bDiff * bDiff)
    }
}
