package com.example.colorbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

/**
 * Bu servis, ekran üzerindeki belirli (x, y) koordinatlarına dokunma
 * (tap) jesti göndermekten sorumludur. Botun "parmak" kısmıdır.
 */
class ColorAccessibilityService : AccessibilityService() {

    companion object {
        // Diğer bileşenlerin (OverlayService) bu servise erişebilmesi için basit bir referans.
        @Volatile
        var instance: ColorAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) instance = null
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Bu botun tek görevi dokunma göndermek olduğu için olay dinlemeye ihtiyacımız yok.
    }

    override fun onInterrupt() {
        // Gerekli değil.
    }

    /**
     * Verilen ekran koordinatına kısa bir dokunuş (tap) gönderir.
     */
    fun tap(x: Float, y: Float, durationMs: Long = 50L, callback: ((Boolean) -> Unit)? = null) {
        val path = Path().apply {
            moveTo(x, y)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()

        val dispatched = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                callback?.invoke(true)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                callback?.invoke(false)
            }
        }, null)

        if (!dispatched) {
            callback?.invoke(false)
        }
    }
}
