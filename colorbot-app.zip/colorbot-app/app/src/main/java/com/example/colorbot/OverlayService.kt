package com.example.colorbot

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Ekran üzerinde 4 tane sürüklenebilir işaretçi gösterir:
 *  - EYEDROPPER: hedef uygulamadaki damla/renk-seçici ikonunun konumu
 *  - INDICATOR : hedef uygulamanın "gerekli renk"i gösterdiği piksel konumu
 *  - AREA_TL / AREA_BR: taranacak alanın sol-üst ve sağ-alt köşeleri
 *
 * Ayrıca küçük bir kontrol panelinde Başlat/Durdur düğmesi bulunur.
 * Başlatıldığında sürekli şu döngüyü çalıştırır:
 *  1) Eyedropper noktasına dokun
 *  2) Kısa süre bekle, ekran görüntüsünü al
 *  3) Indicator noktasındaki rengi oku (hedef renk)
 *  4) Arama alanında aynı rengi ara, bulamazsa en yakın renkli pikseli bul
 *  5) Bulunan noktaya dokun, tekrar et
 */
class OverlayService : Service() {

    private lateinit var windowManager: WindowManager

    private var eyedropperView: View? = null
    private var indicatorView: View? = null
    private var areaTlView: View? = null
    private var areaBrView: View? = null
    private var panelView: View? = null

    private var eyedropperX = 150
    private var eyedropperY = 400
    private var indicatorX = 150
    private var indicatorY = 300
    private var areaTlX = 100
    private var areaTlY = 600
    private var areaBrX = 700
    private var areaBrY = 1400

    private var loopJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main)
    private var running = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        addMarker(::eyedropperView, eyedropperX, eyedropperY, Color.parseColor("#FF6200EE"), "E") { x, y ->
            eyedropperX = x; eyedropperY = y
        }
        addMarker(::indicatorView, indicatorX, indicatorY, Color.parseColor("#FF03DAC5"), "I") { x, y ->
            indicatorX = x; indicatorY = y
        }
        addMarker(::areaTlView, areaTlX, areaTlY, Color.parseColor("#FFFFC107"), "1") { x, y ->
            areaTlX = x; areaTlY = y
        }
        addMarker(::areaBrView, areaBrX, areaBrY, Color.parseColor("#FFF44336"), "2") { x, y ->
            areaBrX = x; areaBrY = y
        }
        addControlPanel()
    }

    private fun overlayType(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
    }

    /** Sürüklenebilir, renkli, harf etiketli dairesel bir işaretçi ekler. */
    private fun addMarker(
        target: kotlin.reflect.KMutableProperty0<View?>,
        initialX: Int,
        initialY: Int,
        color: Int,
        label: String,
        onMoved: (x: Int, y: Int) -> Unit
    ) {
        val size = 80
        val markerView = TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(color)
                setStroke(3, Color.WHITE)
            }
        }

        val params = WindowManager.LayoutParams(
            size, size,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = initialX
            y = initialY
        }

        var lastTouchX = 0f
        var lastTouchY = 0f
        var lastParamX = 0
        var lastParamY = 0

        markerView.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    lastTouchX = event.rawX
                    lastTouchY = event.rawY
                    lastParamX = params.x
                    lastParamY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - lastTouchX).toInt()
                    val dy = (event.rawY - lastTouchY).toInt()
                    params.x = lastParamX + dx
                    params.y = lastParamY + dy
                    windowManager.updateViewLayout(v, params)
                    onMoved(params.x + size / 2, params.y + size / 2)
                    true
                }
                else -> false
            }
        }

        windowManager.addView(markerView, params)
        target.set(markerView)
    }

    private lateinit var statusLabel: TextView

    private fun addControlPanel() {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#CC000000"))
            setPadding(16, 16, 16, 16)
        }

        statusLabel = TextView(this).apply {
            text = "Durum: bekleniyor"
            setTextColor(Color.WHITE)
            textSize = 12f
        }

        val button = Button(this).apply {
            text = "Başlat"
            setOnClickListener {
                if (!running) {
                    val precheckError = preflightCheck()
                    if (precheckError != null) {
                        Toast.makeText(this@OverlayService, precheckError, Toast.LENGTH_LONG).show()
                        statusLabel.text = "Durum: HATA - $precheckError"
                        return@setOnClickListener
                    }
                    text = "Durdur"
                    startLoop()
                } else {
                    text = "Başlat"
                    stopLoop()
                }
            }
        }

        panel.addView(statusLabel)
        panel.addView(button)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 20
            y = 100
        }

        windowManager.addView(panel, params)
        panelView = panel
    }

    /**
     * Başlatmadan önce gerekli iki bileşeni kontrol eder ve
     * eksikse anlaşılır bir hata mesajı döndürür (null = her şey tamam).
     */
    private fun preflightCheck(): String? {
        if (ColorAccessibilityService.instance == null) {
            return "Erişilebilirlik servisi BAĞLI DEĞİL. Ayarlar > Erişilebilirlik > ColorBot'u açın."
        }
        if (ScreenCaptureService.latestBitmap == null) {
            return "Ekran yakalama başlatılmamış. Önce 'Ekran Yakalamayı Başlat' adımını yapın."
        }
        return null
    }

    private fun startLoop() {
        running = true
        var cycle = 0
        loopJob = scope.launch {
            val accessibility = ColorAccessibilityService.instance
            if (accessibility == null) {
                running = false
                statusLabel.text = "Durum: HATA - Erişilebilirlik servisi bağlı değil"
                return@launch
            }
            while (isActive && running) {
                cycle++
                statusLabel.text = "Durum: çalışıyor (döngü $cycle) - dokunuluyor"

                // 1) Eyedropper noktasına dokun
                accessibility.tap(eyedropperX.toFloat(), eyedropperY.toFloat())
                delay(350)

                // 2) Ekran görüntüsünü al
                val bitmap = ScreenCaptureService.latestBitmap
                if (bitmap == null) {
                    statusLabel.text = "Durum: HATA - ekran görüntüsü yok (yakalama başlatılmamış)"
                } else {
                    // 3) Gerekli rengi oku
                    val safeIndicatorX = indicatorX.coerceIn(0, bitmap.width - 1)
                    val safeIndicatorY = indicatorY.coerceIn(0, bitmap.height - 1)
                    val targetColor = bitmap.getPixel(safeIndicatorX, safeIndicatorY)

                    val left = minOf(areaTlX, areaBrX)
                    val top = minOf(areaTlY, areaBrY)
                    val right = maxOf(areaTlX, areaBrX)
                    val bottom = maxOf(areaTlY, areaBrY)
                    val searchRect = Rect(left, top, right, bottom)

                    // 4) Eşleşen veya en yakın rengi bul
                    val match = ColorMatcher.findMatch(bitmap, searchRect, targetColor)

                    // 5) Bulunan noktaya dokun
                    if (match != null) {
                        accessibility.tap(match.x.toFloat(), match.y.toFloat())
                        statusLabel.text =
                            "Durum: çalışıyor (döngü $cycle) - eşleşme ${if (match.exact) "tam" else "en yakın"} bulundu"
                    } else {
                        statusLabel.text = "Durum: çalışıyor (döngü $cycle) - eşleşme bulunamadı"
                    }
                }

                delay(700)
            }
            if (!running) {
                statusLabel.text = "Durum: durduruldu"
            }
        }
    }

    private fun stopLoop() {
        running = false
        loopJob?.cancel()
        loopJob = null
        statusLabel.text = "Durum: durduruldu"
    }

    override fun onDestroy() {
        super.onDestroy()
        stopLoop()
        listOf(eyedropperView, indicatorView, areaTlView, areaBrView, panelView).forEach { view ->
            if (view != null) {
                try {
                    windowManager.removeView(view)
                } catch (_: Exception) {
                }
            }
        }
    }
}
